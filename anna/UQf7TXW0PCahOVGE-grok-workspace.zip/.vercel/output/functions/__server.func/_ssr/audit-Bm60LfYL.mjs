import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as cn, g as verifyText, i as canonicalize, l as parseUnits, m as useDesk, n as Shell, o as emptyHistory, p as signText, s as evaluate, t as ANNA_POLICY, u as policyCanonical } from "./shell-CGIk5vqZ.mjs";
import { i as transferCalldata, n as extractLocal, r as mergeExtract } from "./extract-ZqY13klI.mjs";
import { r as spentUnits, t as historyFor } from "./ledger-DFBe69tD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-Bm60LfYL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SOURCE = "https://github.com/rudimentall1/verigate/tree/main/anna";
var LINK_GROUPS = [
	{
		title: "Anna — код и архитектура",
		links: [
			{
				label: "Каталог anna/",
				href: "https://github.com/rudimentall1/verigate/tree/main/anna"
			},
			{
				label: "README",
				href: "https://github.com/rudimentall1/verigate/blob/main/anna/README.md"
			},
			{
				label: "app.json",
				href: "https://github.com/rudimentall1/verigate/blob/main/anna/app.json"
			},
			{
				label: "manifest.json",
				href: "https://github.com/rudimentall1/verigate/blob/main/anna/manifest.json"
			}
		]
	},
	{
		title: "Runtime и Executa",
		links: [
			{
				label: "bundle/app.js",
				href: "https://github.com/rudimentall1/verigate/blob/main/anna/bundle/app.js"
			},
			{
				label: "bundle/index.html",
				href: "https://github.com/rudimentall1/verigate/blob/main/anna/bundle/index.html"
			},
			{
				label: "verigate_authority_plugin.py",
				href: "https://github.com/rudimentall1/verigate/blob/main/anna/executas/verigate-authority/verigate_authority_plugin.py"
			},
			{
				label: "Executa manifest",
				href: "https://github.com/rudimentall1/verigate/blob/main/anna/executas/verigate-authority/manifest.json"
			},
			{
				label: "executa.json",
				href: "https://github.com/rudimentall1/verigate/blob/main/anna/executas/verigate-authority/executa.json"
			},
			{
				label: "executa_sdk/",
				href: "https://github.com/rudimentall1/verigate/tree/main/anna/executas/verigate-authority/executa_sdk"
			}
		]
	},
	{
		title: "Состояние и живой прогон",
		links: [
			{
				label: "RELEASE-STATUS.md",
				href: "https://github.com/rudimentall1/verigate/blob/main/anna/docs/RELEASE-STATUS.md"
			},
			{
				label: "Live MetaMask, 9 ноября",
				href: "https://github.com/rudimentall1/verigate/blob/main/anna/docs/history/SESSION-CHECKPOINT-2026-11-10-LIVE-METAMASK.md"
			},
			{
				label: "Release gate 9 ноября",
				href: "https://github.com/rudimentall1/verigate/blob/main/anna/docs/history/RELEASE-GATE-2026-11-09.md"
			},
			{
				label: "CHANGELOG.md",
				href: "https://github.com/rudimentall1/verigate/blob/main/CHANGELOG.md"
			}
		]
	},
	{
		title: "Тесты Anna",
		links: [
			"test_anna_app_bundle.py",
			"test_anna_app_contract.py",
			"test_anna_binary_package.py",
			"test_anna_data_directory.py",
			"test_anna_executa_manifest.py",
			"test_anna_execution_authorization.py",
			"test_anna_package_smoke.py",
			"test_anna_sampling_roundtrip.py",
			"test_anna_state_initialization.py"
		].map((file) => ({
			label: file,
			href: `https://github.com/rudimentall1/verigate/blob/main/tests/${file}`
		}))
	},
	{
		title: "Зависимости, только в контексте Anna",
		links: [
			["core/engine.py", "core/engine.py"],
			["core/policy.py", "core/policy.py"],
			["core/storage.py", "core/storage.py"],
			["core/capabilities.py", "core/capabilities.py"],
			["attest/keys.py", "attest/keys.py"],
			["attest/receipt.py", "attest/receipt.py"],
			["enforcement/evm.py", "enforcement/evm.py"],
			["enforcement/networks.py", "enforcement/networks.py"],
			["enforcement/router.py", "enforcement/router.py"],
			["tests/test_execution_router.py", "tests/test_execution_router.py"],
			["tests/test_evm_enforcement.py", "tests/test_evm_enforcement.py"]
		].map(([label, path]) => ({
			label,
			href: `https://github.com/rudimentall1/verigate/blob/main/${path}`
		}))
	},
	{
		title: "Сборка и CI",
		links: [
			["build_binary.py", "https://github.com/rudimentall1/verigate/blob/main/anna/build_binary.py"],
			["package_binary.py", "https://github.com/rudimentall1/verigate/blob/main/anna/package_binary.py"],
			["smoke_binary.py", "https://github.com/rudimentall1/verigate/blob/main/anna/smoke_binary.py"],
			["smoke_package.py", "https://github.com/rudimentall1/verigate/blob/main/anna/smoke_package.py"],
			["verify_reproducible_binary.py", "https://github.com/rudimentall1/verigate/blob/main/anna/verify_reproducible_binary.py"],
			["anna-executa-binaries.yml", "https://github.com/rudimentall1/verigate/blob/main/.github/workflows/anna-executa-binaries.yml"],
			["CI run 42786256350", "https://github.com/rudimentall1/verigate/actions/runs/42786256350"]
		].map(([label, href]) => ({
			label,
			href
		}))
	}
];
var MATRIX = [
	{
		capability: "Живая сверка политики в этой кассе",
		state: "проверено",
		note: "Кнопка на странице аудита гоняет векторы 0.1.29 в браузере и подписывает пробный чек ключом установки. Это не прогон Python Executa."
	},
	{
		capability: "Разбор платежа хостовой моделью Anna",
		state: "частично",
		note: "Живой прогон 9 ноября есть. Запись не привязана к immutable 0.1.29."
	},
	{
		capability: "Модель не выдаёт полномочие",
		state: "проверено",
		note: "В движке advisory принимается только как WARN. BLOCK модели отбрасывается."
	},
	{
		capability: "ALLOW / WARN / BLOCK по политике Anna",
		state: "проверено",
		note: "Пороги: 500 / 250 / 50 / 2000 USDC и 30 попыток в минуту. Политика policies/anna.yaml."
	},
	{
		capability: "Ed25519 Decision Receipt",
		state: "частично",
		note: "Подпись установки проверяется локально. Внешний потребитель должен получить ключ отдельным каналом."
	},
	{
		capability: "Одноразовое Execution Authorization и consume",
		state: "частично",
		note: "9 ноября ExecutionRouter сжёг разрешение до подписи MetaMask. Повторно его использовать нельзя."
	},
	{
		capability: "Завершённый платёж on-chain",
		state: "не утверждать",
		note: "Подпись в MetaMask отклонена. Hash, inclusion и finality не доказаны."
	},
	{
		capability: "EIP-1193 в свежей сессии Anna Cloud Agent",
		state: "нет",
		note: "Release status прямо помечает это как непроверенное."
	},
	{
		capability: "Solana submission",
		state: "нет",
		note: "В 0.1.29 Solana остаётся на политике и разрешении."
	},
	{
		capability: "Снятие резерва 24ч, если кошелёк отказал",
		state: "нет",
		note: "В App 0.1.29 резерв остаётся. В этой кассе его можно снять вручную — это ещё не продукт Anna."
	},
	{
		capability: "Публикация в Marketplace",
		state: "нет",
		note: "Статус Draft. Review не отправлен. Для гранта это главный блокер."
	},
	{
		capability: "Независимый аудит, HSM, мультиарендность",
		state: "нет",
		note: "Для продажи казначейству нужно. Для подачи на review — нет."
	}
];
var FINDINGS = [
	{
		severity: "High",
		title: "Грант с текущего статуса не берётся",
		detail: "DoraHacks 2349 платит не за репозиторий и не за питч. Нужно опубликованное приложение Anna и 200 квалифицированных MAU за календарный месяц. App 851 стоит в Draft 0.1.29, version ID 2097. Review не отправлен."
	},
	{
		severity: "High",
		title: "Отказ кошелька не возвращает бюджет",
		detail: "Суточный счётчик — это non-BLOCK записи авторизации, не подтверждённые переводы. 9 ноября разрешение сожгли до подписи, пользователь нажал Reject, резерв остался. Для покупателя это списание неслучившегося платежа."
	},
	{
		severity: "Medium",
		title: "Бюджет установки, не человека",
		detail: "Все агенты одной установки делят ключ и лимит. Смена ярлыка агента новый бюджет не открывает. Для команды с несколькими операторами модель «кто сколько может» ещё не собрана."
	},
	{
		severity: "Medium",
		title: "Листинг не должен обещать Solana-перевод",
		detail: "Политика Solana есть, сборки транзакции нет. Расхождение текста карточки и поведения — типичная причина отклонения на review."
	},
	{
		severity: "Low",
		title: "Квалифицированный прогон — это решение, не кошелёк",
		detail: "Осмысленный результат основной функции уже получается на проверке: ALLOW, WARN или BLOCK и подписанный чек. Прятать первый экран за MetaMask снижает число завершённых прогонов. Три готовых примера на старте это чинят."
	}
];
function auditMarkdown() {
	const lines = [
		"# Independent Technical Audit — Anna / Verigate Authority",
		"",
		"Аудитировать только Verigate Authority: UI, bundled Python Executa, Anna Runtime, EIP-1193 и жизненный цикл payment authorization.",
		"Репозиторий: https://github.com/rudimentall1/verigate",
		"Первая ссылка: https://github.com/rudimentall1/verigate/tree/main/anna",
		"Не проводить общий аудит остальных продуктов Verigate. Общие модули смотреть только там, где от них зависит Anna.",
		"",
		"Версии на 10 ноября 2026: App ID 851, immutable Draft 0.1.29 (version ID 2097), Executa 0.1.16 (version ID 1042). Это Draft, не опубликованный продукт.",
		"",
		"Видео MetaMask от 9 ноября подтверждает подключение кошелька, точный перевод и consume ExecutionRouter. Подпись пользователь отклонил. Это не доказательство завершённого платежа. Ролика в открытом доступе нет, его передают отдельно.",
		"",
		"## Что прислать в отчёте",
		"- Findings: Critical / High / Medium / Low, с воспроизведением и ссылкой на код.",
		"- Матрица проверено / не проверено.",
		"- Атаки и результат прогона.",
		"- Что оставить, упростить, заменить, убрать.",
		"- Порядок исправлений, оценка трудоёмкости и зависимости.",
		"- Вердикт готовности к продукту и к продаже.",
		"- Рекомендация: продолжать архитектуру, точечный рефакторинг или смена подхода.",
		"",
		"## Ссылки"
	];
	for (const group of LINK_GROUPS) {
		lines.push(`### ${group.title}`);
		for (const link of group.links) lines.push(`- ${link.label}: ${link.href}`);
		lines.push("");
	}
	lines.push("## Матрица по опубликованному release status");
	for (const row of MATRIX) lines.push(`- ${row.state.toUpperCase()} — ${row.capability}. ${row.note}`);
	lines.push("", "## Наблюдения сборки, не замена независимого аудита");
	for (const finding of FINDINGS) lines.push(`- ${finding.severity} — ${finding.title}. ${finding.detail}`);
	lines.push("", "## Рекомендация", "Архитектуру не менять: модель советует, политика решает, кошелёк подписывает.", "Дальше по порядку: submit review 0.1.29, сверить листинг с Solana и policy-only, вернуть резерв при отказе подписи, оставить на первом экране три примера.", "Не обещать универсальный файрвол для действий в обход ExecutionRouter.");
	return lines.join("\n");
}
var PAYEE = "0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed";
var OTHER = "0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B";
var SOLANA = "7EcDhSYGxXyscszYEp35KHN8vvw3svAuLKTzXwCFLtV";
function row(id, title, expect, actual, pass) {
	return {
		id,
		title,
		expect,
		actual,
		pass
	};
}
function codes(amount, history = emptyHistory(), extra = [], payee = PAYEE, network = "base", asset = "USDC") {
	return evaluate({
		network,
		asset,
		amount,
		payee
	}, ANNA_POLICY, history, extra);
}
function record(overrides) {
	return {
		id: "1",
		createdAt: 1e3,
		exp: 2e3,
		consumedAt: 1500,
		releasedAt: null,
		decision: "ALLOW",
		mode: "ai",
		network: "base",
		asset: "USDC",
		amount: "25",
		payee: PAYEE,
		rules: [],
		policyDigest: "abc",
		decisionCanonical: "{}",
		decisionSig: "sig",
		executionCanonical: "{}",
		executionSig: "sig",
		nonce: "n",
		walletNote: null,
		ignoredModelBlock: false,
		...overrides
	};
}
/** Same vectors as the desk tests. This is the browser twin, not the Python Executa. */
function runConformance() {
	const allow = codes("25");
	const first = codes("80", emptyHistory(), [], OTHER);
	const known = codes("80", {
		...emptyHistory(),
		payeeSeen: true
	}, [], OTHER);
	const review = codes("400", {
		...emptyHistory(),
		payeeSeen: true
	});
	const over = codes("501", {
		...emptyHistory(),
		payeeSeen: true
	});
	const edge = codes("500", {
		...emptyHistory(),
		payeeSeen: true
	});
	const daily = codes("60", {
		spentUnits: parseUnits("1950"),
		payeeSeen: true,
		attemptsLastMinute: 0
	});
	const blocked = evaluate({
		network: "base",
		asset: "USDC",
		amount: "10",
		payee: PAYEE
	}, {
		...ANNA_POLICY,
		blockedPayees: [PAYEE]
	}, emptyHistory());
	const malformed = codes("10", emptyHistory(), [], "0x123");
	const foreign = codes("10", emptyHistory(), [], PAYEE, "base", "USDT");
	const rate = codes("10", {
		...emptyHistory(),
		attemptsLastMinute: 30
	});
	const injected = codes("25", emptyHistory(), [{
		code: "prompt_injection",
		severity: "WARN",
		detail: "injection"
	}]);
	const fakeBlock = codes("25", emptyHistory(), [{
		code: "model_block",
		severity: "BLOCK",
		detail: "no"
	}]);
	const hard = codes("900", emptyHistory(), [{
		code: "prompt_injection",
		severity: "WARN",
		detail: "noise"
	}]);
	const allowlistEmpty = evaluate({
		network: "base",
		asset: "USDC",
		amount: "10",
		payee: PAYEE
	}, {
		...ANNA_POLICY,
		allowedPayees: []
	}, emptyHistory());
	const allowlistHit = evaluate({
		network: "base",
		asset: "USDC",
		amount: "25",
		payee: PAYEE
	}, {
		...ANNA_POLICY,
		allowedPayees: [PAYEE.toLowerCase()]
	}, emptyHistory());
	const solana = codes("10", emptyHistory(), [], SOLANA, "solana");
	const baseText = `Заплати 25 USDC в сети Base на ${PAYEE}`;
	const baseMerge = mergeExtract(baseText, extractLocal(baseText), null);
	const words = "Переведи полтысячи USDC на Base на " + OTHER;
	const invented = mergeExtract(words, extractLocal(words), {
		network: "base",
		asset: "USDC",
		amount: "500",
		payee: OTHER,
		riskFlags: [],
		requestedDecision: "ALLOW"
	});
	const modelBlock = mergeExtract(baseText, extractLocal(baseText), {
		network: "base",
		asset: "USDC",
		amount: "25",
		payee: PAYEE,
		riskFlags: [{
			code: "prompt_injection",
			detail: "override"
		}],
		requestedDecision: "BLOCK"
	});
	const afterModel = modelBlock.intent ? evaluate(modelBlock.intent, ANNA_POLICY, emptyHistory(), modelBlock.advisory) : null;
	const now = 0xe8d4a51000;
	const held = record({
		createdAt: 999999999e3,
		exp: 0xe8d4a513e8,
		consumedAt: now
	});
	const released = spentUnits([record({
		...held,
		releasedAt: now
	})], "USDC", now);
	const seen = historyFor([held], [], "USDC", PAYEE, now).payeeSeen;
	const unseen = historyFor([held], [{ at: 999999999e3 }], "USDC", OTHER, now);
	const calldata = transferCalldata(PAYEE, "25");
	const canonicalA = policyCanonical(ANNA_POLICY);
	const canonicalB = policyCanonical({
		...ANNA_POLICY,
		allowedNetworks: [
			"solana",
			"ethereum",
			"base"
		]
	});
	return [
		row("allow-25", "25 USDC новому адресу", "ALLOW", allow.decision, allow.decision === "ALLOW" && allow.rules.length === 0),
		row("warn-80", "80 USDC в первый раз", "WARN new_payee_cap_exceeded", `${first.decision} ${first.rules.map((rule) => rule.code).join(",")}`, first.decision === "WARN" && first.rules.map((rule) => rule.code).join(",") === "new_payee_cap_exceeded"),
		row("allow-known", "80 USDC знакомому адресу", "ALLOW", known.decision, known.decision === "ALLOW"),
		row("review-400", "400 USDC знакомому", "WARN confirmation_required", `${review.decision} ${review.rules[0]?.code ?? ""}`, review.decision === "WARN" && review.rules[0]?.code === "confirmation_required"),
		row("block-501", "501 USDC", "BLOCK per_tx_cap_exceeded", `${over.decision} ${over.rules.map((rule) => rule.code).join(",")}`, over.decision === "BLOCK" && over.rules.some((rule) => rule.code === "per_tx_cap_exceeded")),
		row("edge-500", "500 USDC ещё внутри потолка", "WARN, без per_tx", `${edge.decision}`, edge.decision === "WARN" && !edge.rules.some((rule) => rule.code === "per_tx_cap_exceeded")),
		row("daily", "60 поверх резерва 1950", "BLOCK daily_cap_exceeded", `${daily.decision} ${daily.rules[0]?.code ?? ""}`, daily.decision === "BLOCK" && daily.rules[0]?.code === "daily_cap_exceeded"),
		row("blocked", "Адрес из запрета", "BLOCK blocked_payee", blocked.rules.map((rule) => rule.code).join(","), blocked.decision === "BLOCK" && blocked.rules.some((rule) => rule.code === "blocked_payee")),
		row("format", "Короткий 0x", "BLOCK payee_format", malformed.rules.map((rule) => rule.code).join(","), malformed.rules.some((rule) => rule.code === "payee_format")),
		row("asset", "USDT", "BLOCK", foreign.decision, foreign.decision === "BLOCK"),
		row("rate", "30 попыток за минуту", "BLOCK rate_limit_exceeded", rate.rules.map((rule) => rule.code).join(","), rate.rules.some((rule) => rule.code === "rate_limit_exceeded")),
		row("advisory", "WARN модели поднимает ALLOW", "WARN", injected.decision, injected.decision === "WARN"),
		row("drop-block", "BLOCK модели выбрасывается", "ALLOW", fakeBlock.decision, fakeBlock.decision === "ALLOW" && fakeBlock.rules.length === 0),
		row("warn-loses", "WARN не перекрывает потолок 900", "BLOCK", hard.decision, hard.decision === "BLOCK"),
		row("allowlist-empty", "Пустой белый список", "BLOCK payee_not_allowlisted", allowlistEmpty.rules.map((rule) => rule.code).join(","), allowlistEmpty.rules.some((rule) => rule.code === "payee_not_allowlisted")),
		row("allowlist-hit", "Адрес из белого списка", "ALLOW", allowlistHit.decision, allowlistHit.decision === "ALLOW"),
		row("solana", "10 USDC, адрес Solana", "ALLOW", solana.decision, solana.decision === "ALLOW"),
		row("extract", "Явный текст Base", "policy-only, полный разбор", baseMerge.mode + (baseMerge.complete ? ", complete" : ", incomplete"), baseMerge.complete && baseMerge.mode === "policy-only" && baseMerge.intent?.amount === "25"),
		row("words", "«Полтысячи» и сумма модели 500", "отказ, 500 не в тексте", invented.rejected.join(" "), !invented.complete && invented.intent === null && invented.rejected.join(" ").includes("500")),
		row("model-block", "Модель просит BLOCK на 25 USDC", "WARN, без BLOCK", afterModel ? afterModel.decision : "нет намерения", Boolean(afterModel && modelBlock.ignoredModelBlock && afterModel.decision === "WARN" && !afterModel.rules.some((rule) => rule.severity === "BLOCK"))),
		row("budget", "Резерв и снятие", "25 в бюджете, 0 после снятия", `${spentUnits([held], "USDC", now).toString()} / ${released.toString()}`, spentUnits([held], "USDC", now) === parseUnits("25") && released === 0n),
		row("seen", "Адрес считается знакомым только после полномочия", "этот виден, другой нет", `${seen} / ${unseen.payeeSeen}`, seen && !unseen.payeeSeen && unseen.attemptsLastMinute === 1),
		row("calldata", "ERC-20 transfer 25 USDC", "0xa9059cbb … 017d7840", calldata ?? "нет", Boolean(calldata?.startsWith("0xa9059cbb") && calldata.toLowerCase().includes(PAYEE.slice(2).toLowerCase()) && calldata.endsWith("017d7840"))),
		row("money", "Седьмой знак после запятой", "отказ", String(parseUnits("1.1234567")), parseUnits("1.1234567") === null && parseUnits("25") === 25000000n),
		row("digest", "Отпечаток политики не зависит от порядка сетей", "одна строка", canonicalA === canonicalB ? "совпало" : "разошлось", canonicalA === canonicalB && canonicalA.includes("\"daily_cap\":{\"USDC\":\"2000\"}"))
	];
}
var STATE_CLASS = {
	проверено: "text-allow",
	частично: "text-warn",
	нет: "text-block",
	"не утверждать": "text-block"
};
function download(name, text, type) {
	const blob = new Blob([text], { type });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = name;
	link.click();
	URL.revokeObjectURL(url);
}
function AuditPage() {
	const fingerprint = useDesk((state) => state.issuer?.fingerprint ?? null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [checks, setChecks] = (0, import_react.useState)(null);
	const [signature, setSignature] = (0, import_react.useState)("idle");
	const [running, setRunning] = (0, import_react.useState)(false);
	const failed = checks?.filter((check) => !check.pass).length ?? 0;
	const passed = checks ? checks.length - failed : 0;
	async function run() {
		setRunning(true);
		const list = runConformance();
		setChecks(list);
		const issuer = useDesk.getState().issuer;
		if (!issuer) {
			setSignature("nokey");
			setRunning(false);
			return;
		}
		const body = canonicalize({
			kind: "conformance-probe",
			v: 1,
			amount: "25",
			decision: "ALLOW"
		});
		const signed = await signText(issuer.privatePkcs8B64, body);
		const intact = await verifyText(issuer.publicRawB64, body, signed);
		const tampered = await verifyText(issuer.publicRawB64, `${body} `, signed);
		setSignature(intact && !tampered ? "ok" : "bad");
		setRunning(false);
	}
	function evidence() {
		download("anna-desk-conformance.json", JSON.stringify({
			product: "Verigate Authority desk",
			comparesTo: "Anna App immutable Draft 0.1.29 policy numbers",
			not: "Not the Python Executa, not a chain payment, not marketplace publication.",
			fingerprint,
			signature: signature === "ok" ? "Ed25519 probe verified; a one-byte tamper failed verification." : signature,
			passed,
			failed,
			checks
		}, null, 2), "application/json");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-widest text-copper",
				children: "ПАКЕТ ДЛЯ АУДИТА"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 text-lg font-semibold",
				children: "Только Anna, не весь Verigate"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-md border border-line px-4 text-sm",
					onClick: () => download("anna-audit-brief.md", auditMarkdown(), "text/markdown"),
					children: "Скачать бриф"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-md bg-ink px-4 text-sm font-medium text-paper",
					onClick: () => {
						navigator.clipboard.writeText(auditMarkdown()).then(() => setCopied(true), () => setCopied(false));
					},
					children: copied ? "Скопировано" : "Скопировать бриф"
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-3xl text-sm text-ink-soft",
			children: "Это текст, который можно отдать проверяющим вместе со ссылками. Видео MetaMask от 9 ноября в репозитории нет: оно подтверждает кошелёк и сожжённое разрешение, но не завершённый платёж. Передавать ролик отдельно."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-sm",
			children: [
				"Первая ссылка:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "text-copper break-all",
					href: SOURCE,
					children: SOURCE
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 border border-line bg-card p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "Сверка на этом устройстве"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-ink-soft",
					children: "Те же цифры, что в политике 0.1.29: потолок 500, новый адрес 50, просмотр свыше 250, бюджет 2000, 30 попыток в минуту. Ключ установки подписывает пробный чек. Журнал и бюджет не меняются."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void run(),
						disabled: running,
						className: "min-h-11 rounded-md bg-copper px-4 text-sm font-medium text-paper disabled:opacity-50",
						children: running ? "Сверяю" : "Прогнать"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: evidence,
						disabled: !checks,
						className: "min-h-11 rounded-md border border-line px-4 text-sm disabled:opacity-50",
						children: "Скачать свидетельство"
					})]
				})]
			}), checks ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 font-mono text-sm tabular-nums",
				children: [
					passed,
					" сошлось",
					failed > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-block",
						children: [
							" · ",
							failed,
							" разошлось"
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-ink-soft",
						children: [
							" ",
							"· подпись ",
							signature === "ok" ? "сходится, подмена нет" : signature === "bad" ? "не сошлась" : signature === "nokey" ? "ключа ещё нет" : "—",
							fingerprint ? ` · ${fingerprint}` : ""
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-line border-t border-line",
				children: checks.map((check) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-1 py-2 sm:grid-cols-[1.4rem_1fr_auto] sm:items-baseline sm:gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("font-mono text-xs", check.pass ? "text-allow" : "text-block"),
							children: check.pass ? "да" : "нет"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: check.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-ink-soft sm:text-right",
							children: check.pass ? check.expect : `${check.expect} → ${check.actual}`
						})
					]
				}, check.id))
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-ink-soft",
				children: "Пока не запускалось. Это сверка кассы, не отчёт по репозиторию anna/."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 border border-block bg-block-bg p-4 text-block",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "Что реально решает грант"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm",
				children: "У программы Anna AI App Builder нет жюри и призовых мест. Платят за опубликованное приложение и 200 квалифицированных MAU за один месяц сентября, октября или ноября 2026. Репозиторий, эта касса и демо-ролик заявкой не являются. App 851 до сих пор Draft: review версии 0.1.29 не отправлен."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "Вердикт"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-3xl text-sm",
				children: "Архитектуру менять не нужно. Граница верная: модель советует, политика решает, кошелёк подписывает. Дальше — отправить 0.1.29 на review, не обещать в карточке перевод Solana, вернуть резерв, если подпись отклонена, и оставить на первом экране готовые примеры. Универсальный файрвол для действий в обход ExecutionRouter обещать нельзя: его нет."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "Наблюдения"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-ink-soft",
					children: "Это не отчёт аудитора. Это чтение release status, anna.yaml и движка."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-3",
					children: FINDINGS.map((finding) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border border-line bg-card p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs text-copper",
								children: finding.severity
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-medium",
								children: finding.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-ink-soft",
								children: finding.detail
							})
						]
					}, finding.title))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 overflow-x-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "Матрица"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "mt-3 w-full min-w-[36rem] border-collapse text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-line text-left text-xs text-ink-soft",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-3 font-medium",
							children: "Способность"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-3 font-medium",
							children: "Сейчас"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 font-medium",
							children: "Граница"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: MATRIX.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-line align-top",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 pr-3",
							children: row.capability
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: cn("py-2 pr-3 font-mono text-xs", STATE_CLASS[row.state]),
							children: row.state
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 text-ink-soft",
							children: row.note
						})
					]
				}, row.capability)) })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-4 md:grid-cols-2",
			children: LINK_GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border border-line bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: group.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 space-y-1 text-sm",
					children: group.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-copper break-all",
						href: link.href,
						children: link.label
					}) }, link.href))
				})]
			}, group.title))
		})
	] });
}
//#endregion
export { AuditPage as component };

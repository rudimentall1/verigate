import { i as canonicalize, l as parseUnits } from "./shell-CGIk5vqZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ledger-DFBe69tD.js
var DAY = 864e5;
var MINUTE = 6e4;
function spentUnits(records, asset, now) {
	return records.reduce((sum, record) => {
		if (record.asset.toUpperCase() !== asset.toUpperCase()) return sum;
		if (record.decision === "BLOCK" || !record.executionSig || record.releasedAt !== null) return sum;
		if (now - record.createdAt > DAY) return sum;
		const units = parseUnits(record.amount);
		return units === null ? sum : sum + units;
	}, 0n);
}
function historyFor(records, attempts, asset, payee, now) {
	const needle = payee.toLowerCase();
	return {
		spentUnits: spentUnits(records, asset, now),
		payeeSeen: records.some((record) => record.payee.toLowerCase() === needle && record.decision !== "BLOCK" && record.executionSig !== null),
		attemptsLastMinute: attempts.filter((attempt) => now - attempt.at < MINUTE).length
	};
}
function issueCanonical(intent, ruleCodes) {
	return canonicalize({
		amount: intent.amount,
		asset: intent.asset.toUpperCase(),
		network: intent.network.toLowerCase(),
		payee: intent.payee,
		purpose: "issue",
		rules: [...ruleCodes].sort()
	});
}
function submitCanonical(record) {
	return canonicalize({
		amount: record.amount,
		asset: record.asset.toUpperCase(),
		network: record.network.toLowerCase(),
		nonce: record.nonce,
		payee: record.payee,
		purpose: "submit"
	});
}
//#endregion
export { submitCanonical as i, issueCanonical as n, spentUnits as r, historyFor as t };

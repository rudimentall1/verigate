import { d as sameUnits, l as parseUnits } from "./shell-CGIk5vqZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/extract-ZqY13klI.js
/** Circle native USDC. Public contract addresses, not secrets. */
var USDC = {
	base: {
		chainId: "0x2105",
		token: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
		chainName: "Base"
	},
	ethereum: {
		chainId: "0x1",
		token: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
		chainName: "Ethereum"
	}
};
function transferCalldata(payee, amount) {
	if (!/^0x[a-fA-F0-9]{40}$/.test(payee)) return null;
	const units = parseUnits(amount);
	if (units === null) return null;
	return `0xa9059cbb${payee.slice(2).toLowerCase().padStart(64, "0")}${units.toString(16).padStart(64, "0")}`;
}
var FLAG_CODES = /* @__PURE__ */ new Set([
	"prompt_injection",
	"urgency_pressure",
	"purpose_mismatch",
	"social_engineering",
	"lookalike_payee"
]);
var NETWORK_RULES = [
	[/\bethereum\b|эфириум/i, "ethereum"],
	[/\bbase\b/i, "base"],
	[/\bsolana\b/i, "solana"]
];
function unique(values) {
	return [...new Set(values)];
}
function networksIn(text) {
	return unique(NETWORK_RULES.filter(([rule]) => rule.test(text)).map(([, name]) => name));
}
function assetsIn(text) {
	return unique([...text.matchAll(/\b(usdc|usdt|dai)\b/gi)].map((match) => match[1].toUpperCase()));
}
function evmAddresses(text) {
	return unique([...text.matchAll(/\b0x[a-fA-F0-9]{40}\b/g)].map((match) => match[0]));
}
function solanaAddresses(text) {
	return unique([...text.matchAll(/\b[1-9A-HJ-NP-Za-km-z]{32,44}\b/g)].map((match) => match[0]).filter((value) => !/^0x/i.test(value)));
}
function amountsIn(text) {
	const stripped = text.replace(/0x[a-fA-F0-9]{40}/g, " ").replace(/\b[1-9A-HJ-NP-Za-km-z]{32,44}\b/g, " ");
	const found = [];
	for (const pattern of [
		/(\d{1,9}(?:[.,]\d{1,8})?)\s*(?:usdc|usd)\b/gi,
		/\b(?:usdc|usd)\s*(\d{1,9}(?:[.,]\d{1,8})?)/gi,
		/\$\s*(\d{1,9}(?:[.,]\d{1,8})?)/gi
	]) for (const match of stripped.matchAll(pattern)) found.push(match[1].replace(",", "."));
	const parsed = found.map((value) => ({
		value,
		units: parseUnits(value)
	})).filter((item) => item.units !== null);
	const distinct = [];
	for (const item of parsed) if (!distinct.some((have) => sameUnits(have, item.value))) distinct.push(item.value);
	return distinct;
}
function extractLocal(text) {
	const missing = [];
	const conflicts = [];
	const networks = networksIn(text);
	const assets = assetsIn(text);
	const amounts = amountsIn(text);
	const evm = evmAddresses(text);
	const sol = solanaAddresses(text);
	let network;
	if (networks.length === 1) network = networks[0];
	else if (networks.length > 1) conflicts.push("В тексте несколько сетей. Оставьте одну: Base, Ethereum или Solana.");
	else missing.push("Укажите сеть: Base, Ethereum или Solana.");
	let asset;
	if (assets.length === 1) asset = assets[0];
	else if (assets.length > 1) conflicts.push("В тексте несколько активов. Оставьте один.");
	else missing.push("Укажите актив. Политика Anna по умолчанию пропускает только USDC.");
	let amount;
	if (amounts.length === 1) {
		if (parseUnits(amounts[0]) === null) conflicts.push("Сумма не читается как USDC с точностью до 6 знаков.");
		else amount = amounts[0];
	} else if (amounts.length > 1) conflicts.push("В тексте несколько разных сумм. Оставьте одну.");
	else missing.push("Укажите сумму числом, например 25 USDC. Слова вроде «полтысячи» не принимаются.");
	let payee;
	const pool = network === "solana" ? sol : network === "base" || network === "ethereum" ? evm : [...evm, ...sol];
	if (network === "solana" && evm.length > 0) conflicts.push("Сеть Solana, но в тексте есть EVM-адрес.");
	if ((network === "base" || network === "ethereum") && sol.length > 0 && evm.length === 0) conflicts.push("Сеть EVM, а адрес похож на Solana.");
	if (pool.length === 1) payee = pool[0];
	else if (pool.length > 1) conflicts.push("В тексте несколько адресов. Оставьте одного получателя.");
	else missing.push("Укажите адрес получателя целиком.");
	return {
		network,
		asset,
		amount,
		payee,
		missing,
		conflicts
	};
}
function appears(text, value) {
	return text.toLowerCase().includes(value.trim().toLowerCase());
}
function literalPayee(text, candidate) {
	const escaped = candidate.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	const match = text.match(new RegExp(escaped, "i"));
	return match ? match[0] : null;
}
var FLAG_DETAIL = {
	prompt_injection: "Модель видит попытку продавить ALLOW. На решение это не влияет.",
	urgency_pressure: "В запросе давление срочностью. Это повод для WARN, не для пропуска.",
	purpose_mismatch: "Назначение и платёж расходятся. Модель только поднимает проверку.",
	social_engineering: "Похоже на давление авторитетом. Политика от этого не мягче.",
	lookalike_payee: "Адрес похож на подмену. Сам по себе это не BLOCK."
};
function mergeExtract(text, local, model) {
	const rejected = [];
	const conflicts = [...local.conflicts];
	const missing = [...local.missing];
	let network = local.network;
	let asset = local.asset;
	let amount = local.amount;
	let payee = local.payee;
	const take = (field, value, have) => {
		if (!value || !value.trim()) return have;
		const clean = value.trim();
		if (field === "payee") {
			const literal = literalPayee(text, clean);
			if (!literal) {
				rejected.push(`Модель назвала адрес ${clean}, но этой строки в запросе нет.`);
				return have;
			}
			if (have && have.toLowerCase() !== literal.toLowerCase()) {
				conflicts.push("Модель и текст разошлись в адресе. Уточните получателя.");
				return have;
			}
			return have ?? literal;
		}
		if (field === "amount") {
			if (!appears(text, clean.replace(/\.0+$/, "")) && !appears(text, clean)) {
				const units = parseUnits(clean);
				const localUnits = have ? parseUnits(have) : null;
				if (units !== null && localUnits !== null && units === localUnits) return have;
				rejected.push(`Модель назвала сумму ${clean}, но в тексте её нет.`);
				return have;
			}
			if (have && !sameUnits(have, clean)) {
				conflicts.push("Модель и текст разошлись в сумме. Напишите одну цифру.");
				return have;
			}
			return have ?? clean;
		}
		const normalized = field === "asset" ? clean.toUpperCase() : clean.toLowerCase();
		if (!appears(text, normalized) && !(field === "network" && appears(text, clean))) {
			rejected.push(`Модель назвала ${field === "asset" ? "актив" : "сеть"} ${clean}, но в тексте этого нет.`);
			return have;
		}
		if (have && have.toLowerCase() !== normalized.toLowerCase()) {
			conflicts.push(field === "asset" ? "Модель и текст разошлись в активе." : "Модель и текст разошлись в сети.");
			return have;
		}
		return have ?? normalized;
	};
	if (model) {
		network = take("network", model.network, network);
		asset = take("asset", model.asset, asset);
		amount = take("amount", model.amount, amount);
		payee = take("payee", model.payee, payee);
	}
	const questions = unique([...conflicts, ...missing.filter((item) => {
		if (item.startsWith("Укажите сеть") && network) return false;
		if (item.startsWith("Укажите актив") && asset) return false;
		if (item.startsWith("Укажите сумму") && amount) return false;
		if (item.startsWith("Укажите адрес") && payee) return false;
		return true;
	})]);
	const advisory = [];
	let ignoredModelBlock = false;
	if (model) {
		const requested = model.requestedDecision?.toUpperCase() ?? null;
		if (requested === "BLOCK" || requested === "ALLOW") {
			if (requested === "BLOCK") ignoredModelBlock = true;
		}
		for (const flag of model.riskFlags) {
			if (!FLAG_CODES.has(flag.code)) continue;
			advisory.push({
				code: flag.code,
				severity: "WARN",
				detail: FLAG_DETAIL[flag.code] ?? flag.detail.slice(0, 180)
			});
		}
		if (requested === "BLOCK") {
			advisory.push({
				code: "ignored_model_block",
				severity: "WARN",
				detail: "Модель просила BLOCK. Этот вердикт выброшен: запрещать может только политика."
			});
			ignoredModelBlock = true;
		}
	}
	const complete = questions.length === 0 && Boolean(network && asset && amount && payee);
	return {
		complete,
		questions,
		rejected,
		intent: complete ? {
			network,
			asset,
			amount,
			payee
		} : null,
		mode: model ? "ai" : "policy-only",
		advisory: model ? advisory : [],
		ignoredModelBlock: model ? ignoredModelBlock : false,
		modelRequested: model?.requestedDecision ?? null
	};
}
//#endregion
export { transferCalldata as i, extractLocal as n, mergeExtract as r, USDC as t };

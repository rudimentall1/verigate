import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as formatUnits, h as useNow, l as parseUnits, m as useDesk, n as Shell, t as ANNA_POLICY } from "./shell-CGIk5vqZ.mjs";
import { r as spentUnits, t as historyFor } from "./ledger-DFBe69tD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ledger-CLmgnVR0.js
var import_jsx_runtime = require_jsx_runtime();
function status(record) {
	if (record.decision === "BLOCK" || !record.executionSig) return "попытка без полномочия";
	if (record.releasedAt) return "резерв снят";
	if (record.consumedAt) return "разрешение использовано";
	if (record.exp !== null && record.exp < Date.now()) return "разрешение истекло";
	return "резерв держится";
}
function LedgerPage() {
	const records = useDesk((state) => state.records);
	const attempts = useDesk((state) => state.attempts);
	const policy = useDesk((state) => state.policy);
	const now = useNow(true);
	const moment = now ?? 0;
	const spentRaw = spentUnits(records, "USDC", moment);
	const spent = formatUnits(spentRaw);
	const cap = policy.dailyCap.USDC ?? ANNA_POLICY.dailyCap.USDC;
	const pace = historyFor(records, attempts, "USDC", "", moment).attemptsLastMinute;
	const capUnits = cap ? parseUnits(cap) : null;
	const width = capUnits && capUnits > 0n ? Math.min(100, Number(spentRaw * 100n / capUnits)) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold",
			children: "Журнал установки"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 max-w-2xl text-sm text-ink-soft",
			children: "В бюджет попадают только выпущенные разрешения, не превью и не BLOCK. Снятие резерва остаётся в журнале. Это локальная касса, не сеть."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 border border-line bg-card p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono tabular-nums",
					children: [
						spent,
						" / ",
						cap,
						" USDC"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-ink-soft",
					children: [
						"попыток за минуту ",
						now ? pace : "—",
						" / ",
						policy.rateLimitPerMinute
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-2 bg-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-2 bg-copper",
					style: { width: `${width}%` }
				})
			})]
		}),
		records.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-ink-soft",
			children: "Пока пусто. Проверка без подтверждения сюда не пишется."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 divide-y divide-line border border-line bg-card",
			children: records.map((record) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-col gap-2 px-3 py-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-sm",
						children: [
							record.decision,
							" · ",
							record.amount,
							" ",
							record.asset,
							" · ",
							record.network
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "break-all font-mono text-xs text-ink-soft",
						children: record.payee
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-ink-soft",
						children: [
							new Date(record.createdAt).toLocaleString("ru-RU"),
							" · ",
							status(record)
						]
					}),
					record.walletNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm",
						children: record.walletNote
					}) : null
				] }), record.executionSig && record.decision !== "BLOCK" && !record.releasedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 shrink-0 rounded-md border border-line px-3 text-sm",
					onClick: () => useDesk.getState().release(record.id),
					children: "Снять резерв"
				}) : null]
			}, record.id))
		})
	] });
}
//#endregion
export { LedgerPage as component };

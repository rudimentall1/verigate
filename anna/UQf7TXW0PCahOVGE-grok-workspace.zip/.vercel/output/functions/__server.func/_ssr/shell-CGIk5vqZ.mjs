import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-CGIk5vqZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function bytesToB64(bytes) {
	let binary = "";
	for (const byte of bytes) binary += String.fromCharCode(byte);
	return btoa(binary);
}
function b64ToBuf(value) {
	const binary = atob(value);
	const buffer = new ArrayBuffer(binary.length);
	const bytes = new Uint8Array(buffer);
	for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
	return buffer;
}
function bytesToHex(bytes) {
	return [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
async function sha256Hex(text) {
	const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
	return bytesToHex(new Uint8Array(digest));
}
function formatFingerprint(hex) {
	return hex.slice(0, 16).toUpperCase().replace(/(.{4})/g, "$1·").replace(/·$/, "");
}
async function createIssuer() {
	const pair = await crypto.subtle.generateKey({ name: "Ed25519" }, true, ["sign", "verify"]);
	const raw = new Uint8Array(await crypto.subtle.exportKey("raw", pair.publicKey));
	const pkcs8 = new Uint8Array(await crypto.subtle.exportKey("pkcs8", pair.privateKey));
	const digest = await crypto.subtle.digest("SHA-256", raw);
	return {
		publicRawB64: bytesToB64(raw),
		privatePkcs8B64: bytesToB64(pkcs8),
		publicHex: bytesToHex(raw),
		fingerprint: formatFingerprint(bytesToHex(new Uint8Array(digest)))
	};
}
async function privateKey(pkcs8B64) {
	return crypto.subtle.importKey("pkcs8", b64ToBuf(pkcs8B64), { name: "Ed25519" }, false, ["sign"]);
}
async function publicKey(rawB64) {
	return crypto.subtle.importKey("raw", b64ToBuf(rawB64), { name: "Ed25519" }, true, ["verify"]);
}
async function signText(pkcs8B64, text) {
	const signature = await crypto.subtle.sign({ name: "Ed25519" }, await privateKey(pkcs8B64), new TextEncoder().encode(text));
	return bytesToB64(new Uint8Array(signature));
}
async function verifyText(rawB64, text, signatureB64) {
	return crypto.subtle.verify({ name: "Ed25519" }, await publicKey(rawB64), b64ToBuf(signatureB64), new TextEncoder().encode(text));
}
function canonicalize(value) {
	if (value === null || typeof value !== "object") return JSON.stringify(value);
	if (Array.isArray(value)) return `[${value.map((item) => canonicalize(item)).join(",")}]`;
	return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${canonicalize(item)}`).join(",")}}`;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var BASE = 10n ** 6n;
/** Parse a USDC decimal. `null` if it is not a finite non-negative decimal with ≤6 places. */
function parseUnits(input) {
	const s = input.trim().replace(/\s/g, "").replace(",", ".");
	if (!/^\d+(\.\d+)?$/.test(s)) return null;
	const [whole, frac = ""] = s.split(".");
	if (frac.length > 6) return null;
	if (whole.length > 1 && whole.startsWith("0")) return null;
	try {
		return BigInt(whole) * BASE + BigInt((frac + "000000").slice(0, 6));
	} catch {
		return null;
	}
}
function formatUnits(units) {
	const neg = units < 0n;
	const v = neg ? -units : units;
	const whole = v / BASE;
	const frac = (v % BASE).toString().padStart(6, "0").replace(/0+$/, "");
	const text = frac ? `${whole.toString()}.${frac}` : whole.toString();
	return neg ? `-${text}` : text;
}
function sameUnits(a, b) {
	const pa = parseUnits(a);
	const pb = parseUnits(b);
	return pa !== null && pb !== null && pa === pb;
}
/** Fresh-install policy shipped with Anna App 0.1.29 (`policies/anna.yaml`). */
var ANNA_POLICY = {
	payeeValidation: true,
	requirePositiveAmount: true,
	blockedPayees: [],
	allowedPayees: null,
	allowedNetworks: [
		"base",
		"ethereum",
		"solana"
	],
	allowedAssets: ["USDC"],
	perTxCap: { USDC: "500" },
	newPayeeCap: { USDC: "50" },
	confirmationRequiredOver: { USDC: "250" },
	dailyCap: { USDC: "2000" },
	rateLimitPerMinute: 30
};
function emptyHistory() {
	return {
		spentUnits: 0n,
		payeeSeen: false,
		attemptsLastMinute: 0
	};
}
function capUnits(table, asset) {
	const raw = table[asset.toUpperCase()];
	if (raw === void 0) return null;
	return parseUnits(raw);
}
function payeeProblem(payee, network) {
	const value = payee.trim();
	if (!value) return "Адрес пустой.";
	const net = network.trim().toLowerCase();
	if (net === "base" || net === "ethereum") return /^0x[a-fA-F0-9]{40}$/.test(value) ? null : "Для Base и Ethereum нужен адрес 0x и 40 hex-символов.";
	if (net === "solana") return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(value) ? null : "Для Solana нужен base58-адрес получателя.";
	return "Сеть не из списка, формат адреса не к чему приложить.";
}
function sortedRecord(table) {
	return Object.fromEntries(Object.entries(table).map(([key, value]) => [key.toUpperCase(), value.trim()]).sort(([a], [b]) => a.localeCompare(b)));
}
/** Stable document. The receipt binds to the hash of this string. */
function policyCanonical(policy) {
	const document = {
		allowed_assets: [...policy.allowedAssets].map((item) => item.toUpperCase()).sort(),
		allowed_networks: [...policy.allowedNetworks].map((item) => item.toLowerCase()).sort(),
		allowed_payees: policy.allowedPayees ? [...policy.allowedPayees].map((item) => item.toLowerCase()).sort() : null,
		blocked_payees: [...policy.blockedPayees].map((item) => item.toLowerCase()).sort(),
		confirmation_required_over: sortedRecord(policy.confirmationRequiredOver),
		daily_cap: sortedRecord(policy.dailyCap),
		new_payee_cap: sortedRecord(policy.newPayeeCap),
		payee_validation: policy.payeeValidation,
		per_tx_cap: sortedRecord(policy.perTxCap),
		rate_limit_per_minute: policy.rateLimitPerMinute,
		require_positive_amount: policy.requirePositiveAmount
	};
	return JSON.stringify(document);
}
/**
* Same order and severity as `GuardrailEngine` for a payment intent.
* Advisory input may only add WARN. A model BLOCK is dropped here.
*/
function evaluate(intent, policy, history, advisory = []) {
	const rules = [];
	const asset = intent.asset.toUpperCase();
	const network = intent.network.toLowerCase();
	const payee = intent.payee.trim();
	const amount = parseUnits(intent.amount);
	if (policy.payeeValidation) {
		const problem = payeeProblem(payee, network);
		if (problem) rules.push({
			code: "payee_format",
			severity: "BLOCK",
			detail: problem
		});
	}
	if (policy.requirePositiveAmount && (amount === null || amount <= 0n)) rules.push({
		code: "invalid_amount",
		severity: "BLOCK",
		detail: "Сумма должна быть больше нуля и не длиннее 6 знаков после запятой."
	});
	const blocked = new Set(policy.blockedPayees.map((item) => item.toLowerCase()));
	if (payee && blocked.has(payee.toLowerCase())) rules.push({
		code: "blocked_payee",
		severity: "BLOCK",
		detail: "Получатель в списке запрещённых. Это BLOCK, его не подтверждают."
	});
	if (policy.allowedPayees && !policy.allowedPayees.map((item) => item.toLowerCase()).includes(payee.toLowerCase())) rules.push({
		code: "payee_not_allowlisted",
		severity: "BLOCK",
		detail: "Включён режим списка. Этого адреса в нём нет."
	});
	if (policy.allowedNetworks.length > 0 && !policy.allowedNetworks.map((item) => item.toLowerCase()).includes(network)) rules.push({
		code: "network_not_allowed",
		severity: "BLOCK",
		detail: `Сеть ${network || "—"} не разрешена. Сейчас: ${policy.allowedNetworks.join(", ")}.`
	});
	if (policy.allowedAssets.length > 0 && !policy.allowedAssets.map((item) => item.toUpperCase()).includes(asset)) rules.push({
		code: "asset_not_allowed",
		severity: "BLOCK",
		detail: `Актив ${asset || "—"} не разрешён. Сейчас только ${policy.allowedAssets.join(", ")}.`
	});
	const perTx = capUnits(policy.perTxCap, asset);
	if (amount !== null && perTx !== null && amount > perTx) rules.push({
		code: "per_tx_cap_exceeded",
		severity: "BLOCK",
		detail: `Жёсткий потолок одной транзакции — ${formatUnits(perTx)} ${asset}. Человек его не снимает.`
	});
	const firstCap = capUnits(policy.newPayeeCap, asset);
	if (amount !== null && firstCap !== null && !history.payeeSeen && amount > firstCap) rules.push({
		code: "new_payee_cap_exceeded",
		severity: "WARN",
		detail: `Первое разрешение этому адресу выше ${formatUnits(firstCap)} ${asset}. Это WARN, не запрет.`
	});
	const daily = capUnits(policy.dailyCap, asset);
	if (amount !== null && daily !== null && (amount <= 0n || history.spentUnits + amount > daily)) rules.push({
		code: "daily_cap_exceeded",
		severity: "BLOCK",
		detail: `Вместе с резервом 24 часов (${formatUnits(history.spentUnits)} ${asset}) это выше ${formatUnits(daily)} ${asset}.`
	});
	const reviewOver = capUnits(policy.confirmationRequiredOver, asset);
	if (amount !== null && reviewOver !== null && amount > reviewOver) rules.push({
		code: "confirmation_required",
		severity: "WARN",
		detail: `Сумма выше ${formatUnits(reviewOver)} ${asset}. Нужен отдельный просмотр предупреждений.`
	});
	if (policy.rateLimitPerMinute > 0 && history.attemptsLastMinute >= policy.rateLimitPerMinute) rules.push({
		code: "rate_limit_exceeded",
		severity: "BLOCK",
		detail: `${policy.rateLimitPerMinute} записанных попыток за минуту. Это остановка цикла, не совет модели.`
	});
	for (const flag of advisory) if (flag.severity === "WARN") rules.push(flag);
	return {
		decision: rules.some((rule) => rule.severity === "BLOCK") ? "BLOCK" : rules.some((rule) => rule.severity === "WARN") ? "WARN" : "ALLOW",
		rules
	};
}
var memory = /* @__PURE__ */ new Map();
var storage = createJSONStorage(() => typeof window === "undefined" ? {
	getItem: (name) => memory.get(name) ?? null,
	setItem: (name, value) => void memory.set(name, value),
	removeItem: (name) => void memory.delete(name)
} : localStorage);
var useDesk = create()(persist((set, get) => ({
	policy: ANNA_POLICY,
	issuer: null,
	records: [],
	attempts: [],
	gate: null,
	setPolicy: (policy) => set({ policy }),
	resetPolicy: () => set({ policy: ANNA_POLICY }),
	setIssuer: (issuer) => set({ issuer }),
	openGate: (gate) => set({ gate }),
	clearGate: () => set({ gate: null }),
	noteAttempt: (at) => set({ attempts: [...get().attempts, { at }].slice(-80) }),
	addRecord: (record) => set({ records: [record, ...get().records].slice(0, 100) }),
	consume: (id, note) => {
		const record = get().records.find((item) => item.id === id);
		if (!record?.executionSig) return {
			ok: false,
			reason: "Execution Authorization нет."
		};
		if (record.consumedAt) return {
			ok: false,
			reason: "Разрешение уже использовано. Нужна новая проверка."
		};
		if (record.exp !== null && record.exp < Date.now()) return {
			ok: false,
			reason: "60 секунд прошли. Разрешение больше не действует."
		};
		set({ records: get().records.map((item) => item.id === id ? {
			...item,
			consumedAt: Date.now(),
			walletNote: note
		} : item) });
		return { ok: true };
	},
	setWalletNote: (id, note) => set({ records: get().records.map((item) => item.id === id ? {
		...item,
		walletNote: note
	} : item) }),
	release: (id) => {
		const record = get().records.find((item) => item.id === id);
		if (!record?.executionSig || record.decision === "BLOCK") return {
			ok: false,
			reason: "Снимать нечего."
		};
		if (record.releasedAt) return {
			ok: false,
			reason: "Резерв уже снят."
		};
		set({ records: get().records.map((item) => item.id === id ? {
			...item,
			releasedAt: Date.now()
		} : item) });
		return { ok: true };
	}
}), {
	name: "verigate-authority",
	storage,
	skipHydration: true,
	version: 1,
	partialize: (state) => ({
		policy: state.policy,
		issuer: state.issuer,
		records: state.records,
		attempts: state.attempts
	})
}));
var NAV = [
	{
		to: "/",
		label: "Проверка"
	},
	{
		to: "/ledger",
		label: "Журнал"
	},
	{
		to: "/policy",
		label: "Политика"
	},
	{
		to: "/audit",
		label: "Аудит"
	}
];
function Shell({ children }) {
	const fingerprint = useDesk((state) => state.issuer?.fingerprint ?? null);
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	(0, import_react.useEffect)(() => {
		let dead = false;
		const boot = async () => {
			if (!useDesk.persist.hasHydrated()) await useDesk.persist.rehydrate();
			if (!useDesk.getState().issuer) useDesk.getState().setIssuer(await createIssuer());
			if (dead) return;
		};
		boot();
		return () => {
			dead = true;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "border-b border-line",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-widest text-copper",
							children: "VERIGATE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-semibold leading-tight",
							children: "Касса полномочий"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 max-w-xl text-sm text-ink-soft",
							children: "Модель советует. Потратить она не может. Решение подписывает установка, перевод — только кошелёк."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-xs text-ink-soft sm:text-right",
						children: ["ключ установки", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm text-ink",
							children: fingerprint ?? "создаётся на этом устройстве"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mx-auto flex max-w-6xl gap-2 overflow-x-auto px-4 pb-3",
					children: NAV.map((item) => {
						const path = pathname.length > 1 ? pathname.replace(/\/$/, "") : pathname;
						const active = item.to === "/" ? path === "/" : path === item.to || path.endsWith(item.to);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: cn("inline-flex min-h-11 shrink-0 items-center rounded-md px-3 text-sm font-medium", active ? "bg-ink text-paper" : "text-ink"),
							children: item.label
						}, item.to);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto max-w-6xl px-4 py-6",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mx-auto max-w-6xl px-4 pb-10 text-xs text-ink-soft",
				children: "Anna App 851 · immutable Draft 0.1.29 · Executa 0.1.16. Не опубликован и не является кошельком. Чек доказывает целостность решения этой установки, не факт перевода в сети."
			})
		]
	});
}
function useNow(active) {
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!active) return;
		const tick = () => setNow(Date.now());
		tick();
		const timer = window.setInterval(tick, 1e3);
		return () => window.clearInterval(timer);
	}, [active]);
	return now;
}
//#endregion
export { cn as a, formatUnits as c, sameUnits as d, sha256Hex as f, verifyText as g, useNow as h, canonicalize as i, parseUnits as l, useDesk as m, Shell as n, emptyHistory as o, signText as p, bytesToHex as r, evaluate as s, ANNA_POLICY as t, policyCanonical as u };

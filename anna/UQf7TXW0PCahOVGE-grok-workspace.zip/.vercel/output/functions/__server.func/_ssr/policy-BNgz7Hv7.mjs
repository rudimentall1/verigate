import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as formatUnits, f as sha256Hex, l as parseUnits, m as useDesk, n as Shell, t as ANNA_POLICY, u as policyCanonical } from "./shell-CGIk5vqZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/policy-BNgz7Hv7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PolicyPage() {
	const policy = useDesk((state) => state.policy);
	const setPolicy = useDesk((state) => state.setPolicy);
	const resetPolicy = useDesk((state) => state.resetPolicy);
	const [digest, setDigest] = (0, import_react.useState)("");
	const [payee, setPayee] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		sha256Hex(policyCanonical(policy)).then(setDigest);
	}, [policy]);
	function commitCap(key, raw) {
		const units = parseUnits(raw);
		if (units === null || units <= 0n) {
			setError("Лимит должен быть суммой USDC больше нуля, не длиннее 6 знаков.");
			return;
		}
		setError(null);
		setPolicy({
			...policy,
			[key]: {
				...policy[key],
				USDC: formatUnits(units)
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: "Политика"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-2xl text-sm text-ink-soft",
				children: "Старт — цифры Anna 0.1.29. Смена лимита меняет отпечаток, старые чеки остаются привязаны к старому."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11 rounded-md border border-line px-3 text-sm",
				onClick: () => resetPolicy(),
				children: "Вернуть 0.1.29"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 break-all font-mono text-xs text-ink-soft",
			children: ["digest ", digest || "считается"]
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-block",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-3 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cap, {
					label: "Потолок транзакции, USDC",
					value: policy.perTxCap.USDC ?? "",
					onCommit: (value) => commitCap("perTxCap", value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cap, {
					label: "Первый адрес, WARN выше",
					value: policy.newPayeeCap.USDC ?? "",
					onCommit: (value) => commitCap("newPayeeCap", value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cap, {
					label: "Просмотр человека выше",
					value: policy.confirmationRequiredOver.USDC ?? "",
					onCommit: (value) => commitCap("confirmationRequiredOver", value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cap, {
					label: "Бюджет 24 часов",
					value: policy.dailyCap.USDC ?? "",
					onCommit: (value) => commitCap("dailyCap", value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cap, {
					label: "Попыток в минуту",
					value: String(policy.rateLimitPerMinute),
					onCommit: (value) => {
						const rate = Number(value);
						if (!Number.isInteger(rate) || rate < 1 || rate > 120) {
							setError("Частота — целое от 1 до 120.");
							return;
						}
						setError(null);
						setPolicy({
							...policy,
							rateLimitPerMinute: rate
						});
					}
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 border border-line bg-card p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "Запрещённые адреса"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-ink-soft",
					children: "Совпадение точное, без регистра. Формат здесь не проверяется: блок — это список, не догадка."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 flex flex-col gap-2 sm:flex-row",
					onSubmit: (event) => {
						event.preventDefault();
						const next = payee.trim();
						if (!next) return;
						if (policy.blockedPayees.some((item) => item.toLowerCase() === next.toLowerCase())) {
							setPayee("");
							return;
						}
						setPolicy({
							...policy,
							blockedPayees: [...policy.blockedPayees, next]
						});
						setPayee("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: payee,
						onChange: (event) => setPayee(event.target.value),
						placeholder: "0x… или адрес Solana",
						className: "field font-mono text-sm",
						"aria-label": "Адрес в запрет"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "min-h-11 rounded-md bg-ink px-4 text-sm font-medium text-paper",
						children: "Запретить"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2",
					children: [policy.blockedPayees.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-ink-soft",
						children: "Список пуст, как в поставке."
					}) : null, policy.blockedPayees.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "break-all font-mono text-xs",
							children: item
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 shrink-0 text-sm text-copper",
							onClick: () => setPolicy({
								...policy,
								blockedPayees: policy.blockedPayees.filter((payeeItem) => payeeItem !== item)
							}),
							children: "Убрать"
						})]
					}, item))]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 border border-line bg-card p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-11 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: policy.allowedPayees !== null,
					onChange: (event) => setPolicy({
						...policy,
						allowedPayees: event.target.checked ? policy.allowedPayees ?? [] : null
					})
				}), "Пускать только адреса из списка"]
			}), policy.allowedPayees ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Allowlist, {
				items: policy.allowedPayees,
				onChange: (allowedPayees) => setPolicy({
					...policy,
					allowedPayees
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-ink-soft",
				children: "Выключено: годится любой адрес, которого нет в запрете и который проходит формат сети."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 text-xs text-ink-soft",
			children: [
				"Сети ",
				ANNA_POLICY.allowedNetworks.join(", "),
				" · актив USDC. Их состав в этой кассе не расширяется."
			]
		})
	] });
}
function Cap({ label, value, onCommit }) {
	const [text, setText] = (0, import_react.useState)(value);
	(0, import_react.useEffect)(() => setText(value), [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "field mt-1 font-mono",
			inputMode: "decimal",
			value: text,
			onChange: (event) => setText(event.target.value),
			onBlur: () => onCommit(text)
		})]
	});
}
function Allowlist({ items, onChange }) {
	const [text, setText] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-2 sm:flex-row",
				onSubmit: (event) => {
					event.preventDefault();
					const next = text.trim();
					if (!next) return;
					if (!items.some((item) => item.toLowerCase() === next.toLowerCase())) onChange([...items, next]);
					setText("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: text,
					onChange: (event) => setText(event.target.value),
					className: "field font-mono text-sm",
					"aria-label": "Адрес в список"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "min-h-11 rounded-md border border-line px-4 text-sm",
					children: "Добавить"
				})]
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-block",
				children: "Список пуст, поэтому сейчас не пройдёт ни один адрес."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 space-y-2",
				children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "break-all font-mono text-xs",
						children: item
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 text-sm text-copper",
						onClick: () => onChange(items.filter((payee) => payee !== item)),
						children: "Убрать"
					})]
				}, item))
			})
		]
	});
}
//#endregion
export { PolicyPage as component };

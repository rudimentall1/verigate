//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BuSGlFpW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/audit",
			"/ledger",
			"/policy"
		],
		preloads: ["/assets/index-CD2HvT10.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CD2HvT10.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CaXRM3dj.js",
			"/assets/shell-BeWYz9Sk.js",
			"/assets/extract-D-TdxvIM.js",
			"/assets/ledger-C6yqdX94.js"
		]
	},
	"/audit": {
		filePath: "/workspace/src/routes/audit.tsx",
		children: void 0,
		preloads: [
			"/assets/audit-DFnQtPwc.js",
			"/assets/shell-BeWYz9Sk.js",
			"/assets/extract-D-TdxvIM.js",
			"/assets/ledger-C6yqdX94.js"
		]
	},
	"/ledger": {
		filePath: "/workspace/src/routes/ledger.tsx",
		children: void 0,
		preloads: [
			"/assets/ledger-COvjGZKO.js",
			"/assets/shell-BeWYz9Sk.js",
			"/assets/ledger-C6yqdX94.js"
		]
	},
	"/policy": {
		filePath: "/workspace/src/routes/policy.tsx",
		children: void 0,
		preloads: ["/assets/policy-deWTocHP.js", "/assets/shell-BeWYz9Sk.js"]
	}
} });
//#endregion
export { tsrStartManifest };

import { transferCalldata } from "./erc20.ts";
import { extractLocal, mergeExtract } from "./extract.ts";
import { historyFor, spentUnits, type LedgerRecord } from "./ledger.ts";
import { parseUnits } from "./money.ts";
import { ANNA_POLICY, emptyHistory, evaluate, policyCanonical, type RuleHit } from "./policy.ts";

export type ConformanceCheck = {
  id: string;
  title: string;
  expect: string;
  actual: string;
  pass: boolean;
};

const PAYEE = "0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed";
const OTHER = "0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B";
const SOLANA = "7EcDhSYGxXyscszYEp35KHN8vvw3svAuLKTzXwCFLtV";

function row(id: string, title: string, expect: string, actual: string, pass: boolean): ConformanceCheck {
  return { id, title, expect, actual, pass };
}

function codes(amount: string, history = emptyHistory(), extra: RuleHit[] = [], payee = PAYEE, network = "base", asset = "USDC") {
  return evaluate({ network, asset, amount, payee }, ANNA_POLICY, history, extra);
}

function record(overrides: Partial<LedgerRecord>): LedgerRecord {
  return {
    id: "1",
    createdAt: 1_000,
    exp: 2_000,
    consumedAt: 1_500,
    releasedAt: null,
    decision: "ALLOW",
    mode: "ai",
    network: "base",
    asset: "USDC",
    amount: "25",
    payee: PAYEE,
    rules: [],
    policyDigest: "abc",
    decisionCanonical: "{}",
    decisionSig: "sig",
    executionCanonical: "{}",
    executionSig: "sig",
    nonce: "n",
    walletNote: null,
    ignoredModelBlock: false,
    ...overrides,
  };
}

/** Same vectors as the desk tests. This is the browser twin, not the Python Executa. */
export function runConformance(): ConformanceCheck[] {
  const allow = codes("25");
  const first = codes("80", emptyHistory(), [], OTHER);
  const known = codes("80", { ...emptyHistory(), payeeSeen: true }, [], OTHER);
  const review = codes("400", { ...emptyHistory(), payeeSeen: true });
  const over = codes("501", { ...emptyHistory(), payeeSeen: true });
  const edge = codes("500", { ...emptyHistory(), payeeSeen: true });
  const daily = codes("60", { spentUnits: parseUnits("1950")!, payeeSeen: true, attemptsLastMinute: 0 });
  const blocked = evaluate({ network: "base", asset: "USDC", amount: "10", payee: PAYEE }, { ...ANNA_POLICY, blockedPayees: [PAYEE] }, emptyHistory());
  const malformed = codes("10", emptyHistory(), [], "0x123");
  const foreign = codes("10", emptyHistory(), [], PAYEE, "base", "USDT");
  const rate = codes("10", { ...emptyHistory(), attemptsLastMinute: 30 });
  const injected = codes("25", emptyHistory(), [{ code: "prompt_injection", severity: "WARN", detail: "injection" }]);
  const fakeBlock = codes("25", emptyHistory(), [{ code: "model_block", severity: "BLOCK", detail: "no" }]);
  const hard = codes("900", emptyHistory(), [{ code: "prompt_injection", severity: "WARN", detail: "noise" }]);
  const allowlistEmpty = evaluate(
    { network: "base", asset: "USDC", amount: "10", payee: PAYEE },
    { ...ANNA_POLICY, allowedPayees: [] },
    emptyHistory(),
  );
  const allowlistHit = evaluate(
    { network: "base", asset: "USDC", amount: "25", payee: PAYEE },
    { ...ANNA_POLICY, allowedPayees: [PAYEE.toLowerCase()] },
    emptyHistory(),
  );
  const solana = codes("10", emptyHistory(), [], SOLANA, "solana");

  const baseText = `Заплати 25 USDC в сети Base на ${PAYEE}`;
  const baseMerge = mergeExtract(baseText, extractLocal(baseText), null);
  const words = "Переведи полтысячи USDC на Base на " + OTHER;
  const invented = mergeExtract(words, extractLocal(words), {
    network: "base",
    asset: "USDC",
    amount: "500",
    payee: OTHER,
    riskFlags: [],
    requestedDecision: "ALLOW",
  });
  const modelBlock = mergeExtract(baseText, extractLocal(baseText), {
    network: "base",
    asset: "USDC",
    amount: "25",
    payee: PAYEE,
    riskFlags: [{ code: "prompt_injection", detail: "override" }],
    requestedDecision: "BLOCK",
  });
  const afterModel = modelBlock.intent
    ? evaluate(modelBlock.intent, ANNA_POLICY, emptyHistory(), modelBlock.advisory)
    : null;

  const now = 1_000_000_000_000;
  const held = record({ createdAt: now - 1000, exp: now + 1000, consumedAt: now });
  const released = spentUnits([record({ ...held, releasedAt: now })], "USDC", now);
  const seen = historyFor([held], [], "USDC", PAYEE, now).payeeSeen;
  const unseen = historyFor([held], [{ at: now - 1000 }], "USDC", OTHER, now);
  const calldata = transferCalldata(PAYEE, "25");
  const canonicalA = policyCanonical(ANNA_POLICY);
  const canonicalB = policyCanonical({ ...ANNA_POLICY, allowedNetworks: ["solana", "ethereum", "base"] });

  return [
    row("allow-25", "25 USDC новому адресу", "ALLOW", allow.decision, allow.decision === "ALLOW" && allow.rules.length === 0),
    row("warn-80", "80 USDC в первый раз", "WARN new_payee_cap_exceeded", `${first.decision} ${first.rules.map((rule) => rule.code).join(",")}`, first.decision === "WARN" && first.rules.map((rule) => rule.code).join(",") === "new_payee_cap_exceeded"),
    row("allow-known", "80 USDC знакомому адресу", "ALLOW", known.decision, known.decision === "ALLOW"),
    row("review-400", "400 USDC знакомому", "WARN confirmation_required", `${review.decision} ${review.rules[0]?.code ?? ""}`, review.decision === "WARN" && review.rules[0]?.code === "confirmation_required"),
    row("block-501", "501 USDC", "BLOCK per_tx_cap_exceeded", `${over.decision} ${over.rules.map((rule) => rule.code).join(",")}`, over.decision === "BLOCK" && over.rules.some((rule) => rule.code === "per_tx_cap_exceeded")),
    row("edge-500", "500 USDC ещё внутри потолка", "WARN, без per_tx", `${edge.decision}`, edge.decision === "WARN" && !edge.rules.some((rule) => rule.code === "per_tx_cap_exceeded")),
    row("daily", "60 поверх резерва 1950", "BLOCK daily_cap_exceeded", `${daily.decision} ${daily.rules[0]?.code ?? ""}`, daily.decision === "BLOCK" && daily.rules[0]?.code === "daily_cap_exceeded"),
    row("blocked", "Адрес из запрета", "BLOCK blocked_payee", blocked.rules.map((rule) => rule.code).join(","), blocked.decision === "BLOCK" && blocked.rules.some((rule) => rule.code === "blocked_payee")),
    row("format", "Короткий 0x", "BLOCK payee_format", malformed.rules.map((rule) => rule.code).join(","), malformed.rules.some((rule) => rule.code === "payee_format")),
    row("asset", "USDT", "BLOCK", foreign.decision, foreign.decision === "BLOCK"),
    row("rate", "30 попыток за минуту", "BLOCK rate_limit_exceeded", rate.rules.map((rule) => rule.code).join(","), rate.rules.some((rule) => rule.code === "rate_limit_exceeded")),
    row("advisory", "WARN модели поднимает ALLOW", "WARN", injected.decision, injected.decision === "WARN"),
    row("drop-block", "BLOCK модели выбрасывается", "ALLOW", fakeBlock.decision, fakeBlock.decision === "ALLOW" && fakeBlock.rules.length === 0),
    row("warn-loses", "WARN не перекрывает потолок 900", "BLOCK", hard.decision, hard.decision === "BLOCK"),
    row("allowlist-empty", "Пустой белый список", "BLOCK payee_not_allowlisted", allowlistEmpty.rules.map((rule) => rule.code).join(","), allowlistEmpty.rules.some((rule) => rule.code === "payee_not_allowlisted")),
    row("allowlist-hit", "Адрес из белого списка", "ALLOW", allowlistHit.decision, allowlistHit.decision === "ALLOW"),
    row("solana", "10 USDC, адрес Solana", "ALLOW", solana.decision, solana.decision === "ALLOW"),
    row("extract", "Явный текст Base", "policy-only, полный разбор", baseMerge.mode + (baseMerge.complete ? ", complete" : ", incomplete"), baseMerge.complete && baseMerge.mode === "policy-only" && baseMerge.intent?.amount === "25"),
    row("words", "«Полтысячи» и сумма модели 500", "отказ, 500 не в тексте", invented.rejected.join(" "), !invented.complete && invented.intent === null && invented.rejected.join(" ").includes("500")),
    row("model-block", "Модель просит BLOCK на 25 USDC", "WARN, без BLOCK", afterModel ? afterModel.decision : "нет намерения", Boolean(afterModel && modelBlock.ignoredModelBlock && afterModel.decision === "WARN" && !afterModel.rules.some((rule) => rule.severity === "BLOCK"))),
    row("budget", "Резерв и снятие", "25 в бюджете, 0 после снятия", `${spentUnits([held], "USDC", now).toString()} / ${released.toString()}`, spentUnits([held], "USDC", now) === parseUnits("25") && released === 0n),
    row("seen", "Адрес считается знакомым только после полномочия", "этот виден, другой нет", `${seen} / ${unseen.payeeSeen}`, seen && !unseen.payeeSeen && unseen.attemptsLastMinute === 1),
    row("calldata", "ERC-20 transfer 25 USDC", "0xa9059cbb … 017d7840", calldata ?? "нет", Boolean(calldata?.startsWith("0xa9059cbb") && calldata.toLowerCase().includes(PAYEE.slice(2).toLowerCase()) && calldata.endsWith("017d7840"))),
    row("money", "Седьмой знак после запятой", "отказ", String(parseUnits("1.1234567")), parseUnits("1.1234567") === null && parseUnits("25") === 25_000_000n),
    row("digest", "Отпечаток политики не зависит от порядка сетей", "одна строка", canonicalA === canonicalB ? "совпало" : "разошлось", canonicalA === canonicalB && canonicalA.includes('"daily_cap":{"USDC":"2000"}')),
  ];
}

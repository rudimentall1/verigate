import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { IssuerKey } from "@/lib/crypto";
import type { LedgerRecord } from "@/lib/ledger";
import { ANNA_POLICY, type Policy } from "@/lib/policy";

export type Gate = {
  purpose: "issue" | "submit";
  exp: number;
  canonical: string;
};

type Attempt = { at: number };

type DeskState = {
  policy: Policy;
  issuer: IssuerKey | null;
  records: LedgerRecord[];
  attempts: Attempt[];
  gate: Gate | null;
  setPolicy: (policy: Policy) => void;
  resetPolicy: () => void;
  setIssuer: (issuer: IssuerKey) => void;
  openGate: (gate: Gate) => void;
  clearGate: () => void;
  noteAttempt: (at: number) => void;
  addRecord: (record: LedgerRecord) => void;
  consume: (id: string, note: string) => { ok: true } | { ok: false; reason: string };
  setWalletNote: (id: string, note: string) => void;
  release: (id: string) => { ok: true } | { ok: false; reason: string };
};

const memory = new Map<string, string>();

const storage = createJSONStorage(() =>
  typeof window === "undefined"
    ? {
        getItem: (name: string) => memory.get(name) ?? null,
        setItem: (name: string, value: string) => void memory.set(name, value),
        removeItem: (name: string) => void memory.delete(name),
      }
    : localStorage,
);

export const useDesk = create<DeskState>()(
  persist(
    (set, get) => ({
      policy: ANNA_POLICY,
      issuer: null,
      records: [],
      attempts: [],
      gate: null,
      setPolicy: (policy) => set({ policy }),
      resetPolicy: () => set({ policy: ANNA_POLICY }),
      setIssuer: (issuer) => set({ issuer }),
      openGate: (gate) => set({ gate }),
      clearGate: () => set({ gate: null }),
      noteAttempt: (at) => set({ attempts: [...get().attempts, { at }].slice(-80) }),
      addRecord: (record) => set({ records: [record, ...get().records].slice(0, 100) }),
      consume: (id, note) => {
        const record = get().records.find((item) => item.id === id);
        if (!record?.executionSig) return { ok: false, reason: "Execution Authorization нет." };
        if (record.consumedAt) return { ok: false, reason: "Разрешение уже использовано. Нужна новая проверка." };
        if (record.exp !== null && record.exp < Date.now()) {
          return { ok: false, reason: "60 секунд прошли. Разрешение больше не действует." };
        }
        set({
          records: get().records.map((item) =>
            item.id === id ? { ...item, consumedAt: Date.now(), walletNote: note } : item,
          ),
        });
        return { ok: true };
      },
      setWalletNote: (id, note) =>
        set({
          records: get().records.map((item) => (item.id === id ? { ...item, walletNote: note } : item)),
        }),
      release: (id) => {
        const record = get().records.find((item) => item.id === id);
        if (!record?.executionSig || record.decision === "BLOCK") {
          return { ok: false, reason: "Снимать нечего." };
        }
        if (record.releasedAt) return { ok: false, reason: "Резерв уже снят." };
        set({
          records: get().records.map((item) =>
            item.id === id ? { ...item, releasedAt: Date.now() } : item,
          ),
        });
        return { ok: true };
      },
    }),
    {
      name: "verigate-authority",
      storage,
      skipHydration: true,
      version: 1,
      partialize: (state) => ({
        policy: state.policy,
        issuer: state.issuer,
        records: state.records,
        attempts: state.attempts,
      }),
    },
  ),
);

import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { canonicalize, createIssuer, sha256Hex, signText, verifyText } from "./crypto.ts";
import { extractLocal, mergeExtract } from "./extract.ts";
import { transferCalldata } from "./erc20.ts";
import { historyFor, spentUnits } from "./ledger.ts";
import { formatUnits, parseUnits } from "./money.ts";
import { runConformance } from "./conformance.ts";
import { ANNA_POLICY, emptyHistory, evaluate, type RuleHit } from "./policy.ts";

const PAYEE = "0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed";
const OTHER = "0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B";

function intent(amount: string, payee = PAYEE, network = "base", asset = "USDC") {
  return { network, asset, amount, payee };
}

describe("conformance", () => {
  it("matches every 0.1.29 vector the desk shows auditors", () => {
    const failed = runConformance().filter((check) => !check.pass);
    assert.deepEqual(
      failed.map((check) => `${check.id}: ${check.actual}`),
      [],
    );
  });
});

describe("anna policy", () => {
  it("allows 25 USDC to a new payee", () => {
    const result = evaluate(intent("25"), ANNA_POLICY, emptyHistory());
    assert.equal(result.decision, "ALLOW");
    assert.equal(result.rules.length, 0);
  });

  it("warns on the first authorization above 50 and does not block it", () => {
    const result = evaluate(intent("80"), ANNA_POLICY, emptyHistory());
    assert.equal(result.decision, "WARN");
    assert.deepEqual(result.rules.map((rule) => rule.code), ["new_payee_cap_exceeded"]);
  });

  it("allows 80 USDC once the payee is known and the amount is under 250", () => {
    const result = evaluate(intent("80"), ANNA_POLICY, { ...emptyHistory(), payeeSeen: true });
    assert.equal(result.decision, "ALLOW");
  });

  it("requires review above 250 even for a known payee", () => {
    const result = evaluate(intent("400"), ANNA_POLICY, { ...emptyHistory(), payeeSeen: true });
    assert.equal(result.decision, "WARN");
    assert.equal(result.rules[0]?.code, "confirmation_required");
  });

  it("blocks a single transaction above 500", () => {
    const result = evaluate(intent("501"), ANNA_POLICY, { ...emptyHistory(), payeeSeen: true });
    assert.equal(result.decision, "BLOCK");
    assert.ok(result.rules.some((rule) => rule.code === "per_tx_cap_exceeded"));
  });

  it("treats 500 as still inside the hard cap", () => {
    const result = evaluate(intent("500"), ANNA_POLICY, { ...emptyHistory(), payeeSeen: true });
    assert.equal(result.decision, "WARN");
    assert.equal(result.rules.some((rule) => rule.code === "per_tx_cap_exceeded"), false);
  });

  it("blocks when the 24h authorization budget would be exceeded", () => {
    const result = evaluate(intent("60"), ANNA_POLICY, {
      spentUnits: parseUnits("1950")!,
      payeeSeen: true,
      attemptsLastMinute: 0,
    });
    assert.equal(result.decision, "BLOCK");
    assert.equal(result.rules[0]?.code, "daily_cap_exceeded");
  });

  it("blocks a listed payee, a bad address, a foreign asset and the rate limit", () => {
    const blocked = evaluate(intent("10"), { ...ANNA_POLICY, blockedPayees: [PAYEE] }, emptyHistory());
    assert.equal(blocked.decision, "BLOCK");
    assert.equal(blocked.rules.some((rule) => rule.code === "blocked_payee"), true);

    const malformed = evaluate(intent("10", "0x123"), ANNA_POLICY, emptyHistory());
    assert.equal(malformed.rules.some((rule) => rule.code === "payee_format"), true);

    const asset = evaluate(intent("10", PAYEE, "base", "USDT"), ANNA_POLICY, emptyHistory());
    assert.equal(asset.decision, "BLOCK");

    const rate = evaluate(intent("10"), ANNA_POLICY, { ...emptyHistory(), attemptsLastMinute: 30 });
    assert.equal(rate.rules.some((rule) => rule.code === "rate_limit_exceeded"), true);
  });

  it("lets advisory WARN escalate ALLOW and drops advisory BLOCK", () => {
    const flag: RuleHit = {
      code: "prompt_injection",
      severity: "WARN",
      detail: "injection",
    };
    const escalated = evaluate(intent("25"), ANNA_POLICY, emptyHistory(), [flag]);
    assert.equal(escalated.decision, "WARN");

    const fakeBlock: RuleHit = { code: "model_block", severity: "BLOCK", detail: "no" };
    const ignored = evaluate(intent("25"), ANNA_POLICY, emptyHistory(), [fakeBlock]);
    assert.equal(ignored.decision, "ALLOW");
    assert.equal(ignored.rules.length, 0);
  });

  it("does not let a warning outrank a hard block", () => {
    const result = evaluate(intent("900"), ANNA_POLICY, emptyHistory(), [
      { code: "prompt_injection", severity: "WARN", detail: "noise" },
    ]);
    assert.equal(result.decision, "BLOCK");
  });
});

describe("extractor", () => {
  it("reads an explicit Base payment", () => {
    const text = "Заплати 25 USDC в сети Base на 0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed";
    const local = extractLocal(text);
    assert.equal(local.network, "base");
    assert.equal(local.asset, "USDC");
    assert.equal(local.amount, "25");
    assert.equal(local.payee, PAYEE);
    const merged = mergeExtract(text, local, null);
    assert.equal(merged.complete, true);
    assert.equal(merged.mode, "policy-only");
  });

  it("refuses a model amount that is not in the text", () => {
    const text = "Переведи полтысячи USDC на Base на 0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B";
    const merged = mergeExtract(text, extractLocal(text), {
      network: "base",
      asset: "USDC",
      amount: "500",
      payee: OTHER,
      riskFlags: [],
      requestedDecision: "ALLOW",
    });
    assert.equal(merged.complete, false);
    assert.match(merged.rejected.join(" "), /500/);
    assert.equal(merged.intent, null);
  });

  it("keeps a model BLOCK from becoming the decision", () => {
    const text = "Заплати 25 USDC в сети Base на 0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed";
    const merged = mergeExtract(text, extractLocal(text), {
      network: "base",
      asset: "USDC",
      amount: "25",
      payee: PAYEE,
      riskFlags: [{ code: "prompt_injection", detail: "override" }],
      requestedDecision: "BLOCK",
    });
    assert.equal(merged.complete, true);
    assert.equal(merged.ignoredModelBlock, true);
    const decision = evaluate(merged.intent!, ANNA_POLICY, emptyHistory(), merged.advisory);
    assert.equal(decision.decision, "WARN");
    assert.equal(decision.rules.some((rule) => rule.severity === "BLOCK"), false);
  });
});

describe("money, calldata, ledger", () => {
  it("scales USDC to 6 decimals", () => {
    assert.equal(parseUnits("25")?.toString(), "25000000");
    assert.equal(formatUnits(parseUnits("25.5")!), "25.5");
    assert.equal(parseUnits("1.1234567"), null);
  });

  it("builds ERC-20 transfer calldata", () => {
    const data = transferCalldata(PAYEE, "25");
    assert.ok(data?.startsWith("0xa9059cbb"));
    assert.ok(data?.toLowerCase().includes(PAYEE.slice(2).toLowerCase()));
    assert.ok(data?.endsWith("017d7840"));
  });

  it("counts only unreleased execution authorizations toward the 24h budget", () => {
    const now = 1_000_000_000_000;
    const base = {
      id: "1",
      createdAt: now - 1000,
      exp: now + 1000,
      consumedAt: now,
      releasedAt: null,
      decision: "ALLOW" as const,
      mode: "ai" as const,
      network: "base",
      asset: "USDC",
      amount: "25",
      payee: PAYEE,
      rules: [],
      policyDigest: "abc",
      decisionCanonical: "{}",
      decisionSig: "sig",
      executionCanonical: "{}",
      executionSig: "sig",
      nonce: "n",
      walletNote: null,
      ignoredModelBlock: false,
    };
    assert.equal(spentUnits([base], "USDC", now).toString(), parseUnits("25")!.toString());
    assert.equal(spentUnits([{ ...base, releasedAt: now }], "USDC", now), 0n);
    assert.equal(spentUnits([{ ...base, decision: "BLOCK", executionSig: null }], "USDC", now), 0n);
    const history = historyFor([base], [{ at: now - 1000 }], "USDC", OTHER, now);
    assert.equal(history.payeeSeen, false);
    assert.equal(historyFor([base], [], "USDC", PAYEE, now).payeeSeen, true);
  });
});

describe("ed25519 receipts", () => {
  it("signs and verifies a canonical receipt", async () => {
    const issuer = await createIssuer();
    const body = canonicalize({ kind: "decision", decision: "ALLOW", amount: "25" });
    const signature = await signText(issuer.privatePkcs8B64, body);
    assert.equal(await verifyText(issuer.publicRawB64, body, signature), true);
    assert.equal(await verifyText(issuer.publicRawB64, `${body} `, signature), false);
    assert.equal((await sha256Hex("verigate")).length, 64);
    assert.match(issuer.fingerprint, /^[0-9A-F]{4}·[0-9A-F]{4}·[0-9A-F]{4}·[0-9A-F]{4}$/);
  });
});

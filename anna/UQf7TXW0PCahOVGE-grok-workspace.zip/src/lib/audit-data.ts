export const SOURCE = "https://github.com/rudimentall1/verigate/tree/main/anna";

export const LINK_GROUPS: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: "Anna — код и архитектура",
    links: [
      { label: "Каталог anna/", href: "https://github.com/rudimentall1/verigate/tree/main/anna" },
      { label: "README", href: "https://github.com/rudimentall1/verigate/blob/main/anna/README.md" },
      { label: "app.json", href: "https://github.com/rudimentall1/verigate/blob/main/anna/app.json" },
      { label: "manifest.json", href: "https://github.com/rudimentall1/verigate/blob/main/anna/manifest.json" },
    ],
  },
  {
    title: "Runtime и Executa",
    links: [
      { label: "bundle/app.js", href: "https://github.com/rudimentall1/verigate/blob/main/anna/bundle/app.js" },
      { label: "bundle/index.html", href: "https://github.com/rudimentall1/verigate/blob/main/anna/bundle/index.html" },
      {
        label: "verigate_authority_plugin.py",
        href: "https://github.com/rudimentall1/verigate/blob/main/anna/executas/verigate-authority/verigate_authority_plugin.py",
      },
      {
        label: "Executa manifest",
        href: "https://github.com/rudimentall1/verigate/blob/main/anna/executas/verigate-authority/manifest.json",
      },
      {
        label: "executa.json",
        href: "https://github.com/rudimentall1/verigate/blob/main/anna/executas/verigate-authority/executa.json",
      },
      {
        label: "executa_sdk/",
        href: "https://github.com/rudimentall1/verigate/tree/main/anna/executas/verigate-authority/executa_sdk",
      },
    ],
  },
  {
    title: "Состояние и живой прогон",
    links: [
      {
        label: "RELEASE-STATUS.md",
        href: "https://github.com/rudimentall1/verigate/blob/main/anna/docs/RELEASE-STATUS.md",
      },
      {
        label: "Live MetaMask, 9 ноября",
        href: "https://github.com/rudimentall1/verigate/blob/main/anna/docs/history/SESSION-CHECKPOINT-2026-11-10-LIVE-METAMASK.md",
      },
      {
        label: "Release gate 9 ноября",
        href: "https://github.com/rudimentall1/verigate/blob/main/anna/docs/history/RELEASE-GATE-2026-11-09.md",
      },
      { label: "CHANGELOG.md", href: "https://github.com/rudimentall1/verigate/blob/main/CHANGELOG.md" },
    ],
  },
  {
    title: "Тесты Anna",
    links: [
      "test_anna_app_bundle.py",
      "test_anna_app_contract.py",
      "test_anna_binary_package.py",
      "test_anna_data_directory.py",
      "test_anna_executa_manifest.py",
      "test_anna_execution_authorization.py",
      "test_anna_package_smoke.py",
      "test_anna_sampling_roundtrip.py",
      "test_anna_state_initialization.py",
    ].map((file) => ({
      label: file,
      href: `https://github.com/rudimentall1/verigate/blob/main/tests/${file}`,
    })),
  },
  {
    title: "Зависимости, только в контексте Anna",
    links: [
      ["core/engine.py", "core/engine.py"],
      ["core/policy.py", "core/policy.py"],
      ["core/storage.py", "core/storage.py"],
      ["core/capabilities.py", "core/capabilities.py"],
      ["attest/keys.py", "attest/keys.py"],
      ["attest/receipt.py", "attest/receipt.py"],
      ["enforcement/evm.py", "enforcement/evm.py"],
      ["enforcement/networks.py", "enforcement/networks.py"],
      ["enforcement/router.py", "enforcement/router.py"],
      ["tests/test_execution_router.py", "tests/test_execution_router.py"],
      ["tests/test_evm_enforcement.py", "tests/test_evm_enforcement.py"],
    ].map(([label, path]) => ({
      label,
      href: `https://github.com/rudimentall1/verigate/blob/main/${path}`,
    })),
  },
  {
    title: "Сборка и CI",
    links: [
      ["build_binary.py", "https://github.com/rudimentall1/verigate/blob/main/anna/build_binary.py"],
      ["package_binary.py", "https://github.com/rudimentall1/verigate/blob/main/anna/package_binary.py"],
      ["smoke_binary.py", "https://github.com/rudimentall1/verigate/blob/main/anna/smoke_binary.py"],
      ["smoke_package.py", "https://github.com/rudimentall1/verigate/blob/main/anna/smoke_package.py"],
      [
        "verify_reproducible_binary.py",
        "https://github.com/rudimentall1/verigate/blob/main/anna/verify_reproducible_binary.py",
      ],
      [
        "anna-executa-binaries.yml",
        "https://github.com/rudimentall1/verigate/blob/main/.github/workflows/anna-executa-binaries.yml",
      ],
      ["CI run 42786256350", "https://github.com/rudimentall1/verigate/actions/runs/42786256350"],
    ].map(([label, href]) => ({ label, href })),
  },
];

export const MATRIX: { capability: string; state: "проверено" | "частично" | "нет" | "не утверждать"; note: string }[] = [
  {
    capability: "Живая сверка политики в этой кассе",
    state: "проверено",
    note: "Кнопка на странице аудита гоняет векторы 0.1.29 в браузере и подписывает пробный чек ключом установки. Это не прогон Python Executa.",
  },
  {
    capability: "Разбор платежа хостовой моделью Anna",
    state: "частично",
    note: "Живой прогон 9 ноября есть. Запись не привязана к immutable 0.1.29.",
  },
  {
    capability: "Модель не выдаёт полномочие",
    state: "проверено",
    note: "В движке advisory принимается только как WARN. BLOCK модели отбрасывается.",
  },
  {
    capability: "ALLOW / WARN / BLOCK по политике Anna",
    state: "проверено",
    note: "Пороги: 500 / 250 / 50 / 2000 USDC и 30 попыток в минуту. Политика policies/anna.yaml.",
  },
  {
    capability: "Ed25519 Decision Receipt",
    state: "частично",
    note: "Подпись установки проверяется локально. Внешний потребитель должен получить ключ отдельным каналом.",
  },
  {
    capability: "Одноразовое Execution Authorization и consume",
    state: "частично",
    note: "9 ноября ExecutionRouter сжёг разрешение до подписи MetaMask. Повторно его использовать нельзя.",
  },
  {
    capability: "Завершённый платёж on-chain",
    state: "не утверждать",
    note: "Подпись в MetaMask отклонена. Hash, inclusion и finality не доказаны.",
  },
  {
    capability: "EIP-1193 в свежей сессии Anna Cloud Agent",
    state: "нет",
    note: "Release status прямо помечает это как непроверенное.",
  },
  {
    capability: "Solana submission",
    state: "нет",
    note: "В 0.1.29 Solana остаётся на политике и разрешении.",
  },
  {
    capability: "Снятие резерва 24ч, если кошелёк отказал",
    state: "нет",
    note: "В App 0.1.29 резерв остаётся. В этой кассе его можно снять вручную — это ещё не продукт Anna.",
  },
  {
    capability: "Публикация в Marketplace",
    state: "нет",
    note: "Статус Draft. Review не отправлен. Для гранта это главный блокер.",
  },
  {
    capability: "Независимый аудит, HSM, мультиарендность",
    state: "нет",
    note: "Для продажи казначейству нужно. Для подачи на review — нет.",
  },
];

export const FINDINGS: { severity: "High" | "Medium" | "Low"; title: string; detail: string }[] = [
  {
    severity: "High",
    title: "Грант с текущего статуса не берётся",
    detail:
      "DoraHacks 2349 платит не за репозиторий и не за питч. Нужно опубликованное приложение Anna и 200 квалифицированных MAU за календарный месяц. App 851 стоит в Draft 0.1.29, version ID 2097. Review не отправлен.",
  },
  {
    severity: "High",
    title: "Отказ кошелька не возвращает бюджет",
    detail:
      "Суточный счётчик — это non-BLOCK записи авторизации, не подтверждённые переводы. 9 ноября разрешение сожгли до подписи, пользователь нажал Reject, резерв остался. Для покупателя это списание неслучившегося платежа.",
  },
  {
    severity: "Medium",
    title: "Бюджет установки, не человека",
    detail:
      "Все агенты одной установки делят ключ и лимит. Смена ярлыка агента новый бюджет не открывает. Для команды с несколькими операторами модель «кто сколько может» ещё не собрана.",
  },
  {
    severity: "Medium",
    title: "Листинг не должен обещать Solana-перевод",
    detail:
      "Политика Solana есть, сборки транзакции нет. Расхождение текста карточки и поведения — типичная причина отклонения на review.",
  },
  {
    severity: "Low",
    title: "Квалифицированный прогон — это решение, не кошелёк",
    detail:
      "Осмысленный результат основной функции уже получается на проверке: ALLOW, WARN или BLOCK и подписанный чек. Прятать первый экран за MetaMask снижает число завершённых прогонов. Три готовых примера на старте это чинят.",
  },
];

export function auditMarkdown(): string {
  const lines = [
    "# Independent Technical Audit — Anna / Verigate Authority",
    "",
    "Аудитировать только Verigate Authority: UI, bundled Python Executa, Anna Runtime, EIP-1193 и жизненный цикл payment authorization.",
    "Репозиторий: https://github.com/rudimentall1/verigate",
    "Первая ссылка: https://github.com/rudimentall1/verigate/tree/main/anna",
    "Не проводить общий аудит остальных продуктов Verigate. Общие модули смотреть только там, где от них зависит Anna.",
    "",
    "Версии на 10 ноября 2026: App ID 851, immutable Draft 0.1.29 (version ID 2097), Executa 0.1.16 (version ID 1042). Это Draft, не опубликованный продукт.",
    "",
    "Видео MetaMask от 9 ноября подтверждает подключение кошелька, точный перевод и consume ExecutionRouter. Подпись пользователь отклонил. Это не доказательство завершённого платежа. Ролика в открытом доступе нет, его передают отдельно.",
    "",
    "## Что прислать в отчёте",
    "- Findings: Critical / High / Medium / Low, с воспроизведением и ссылкой на код.",
    "- Матрица проверено / не проверено.",
    "- Атаки и результат прогона.",
    "- Что оставить, упростить, заменить, убрать.",
    "- Порядок исправлений, оценка трудоёмкости и зависимости.",
    "- Вердикт готовности к продукту и к продаже.",
    "- Рекомендация: продолжать архитектуру, точечный рефакторинг или смена подхода.",
    "",
    "## Ссылки",
  ];
  for (const group of LINK_GROUPS) {
    lines.push(`### ${group.title}`);
    for (const link of group.links) lines.push(`- ${link.label}: ${link.href}`);
    lines.push("");
  }
  lines.push("## Матрица по опубликованному release status");
  for (const row of MATRIX) lines.push(`- ${row.state.toUpperCase()} — ${row.capability}. ${row.note}`);
  lines.push("", "## Наблюдения сборки, не замена независимого аудита");
  for (const finding of FINDINGS) lines.push(`- ${finding.severity} — ${finding.title}. ${finding.detail}`);
  lines.push(
    "",
    "## Рекомендация",
    "Архитектуру не менять: модель советует, политика решает, кошелёк подписывает.",
    "Дальше по порядку: submit review 0.1.29, сверить листинг с Solana и policy-only, вернуть резерв при отказе подписи, оставить на первом экране три примера.",
    "Не обещать универсальный файрвол для действий в обход ExecutionRouter.",
  );
  return lines.join("\n");
}

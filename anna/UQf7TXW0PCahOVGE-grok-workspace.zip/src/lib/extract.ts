import { parseUnits, sameUnits } from "./money.ts";
import type { Intent, RuleHit } from "./policy.ts";

export type LocalExtract = {
  network?: string;
  asset?: string;
  amount?: string;
  payee?: string;
  missing: string[];
  conflicts: string[];
};

export type ModelRead = {
  network: string | null;
  asset: string | null;
  amount: string | null;
  payee: string | null;
  riskFlags: { code: string; detail: string }[];
  requestedDecision: string | null;
};

export type MergeResult = {
  complete: boolean;
  questions: string[];
  rejected: string[];
  intent: Intent | null;
  mode: "ai" | "policy-only";
  advisory: RuleHit[];
  ignoredModelBlock: boolean;
  modelRequested: string | null;
};

const FLAG_CODES = new Set([
  "prompt_injection",
  "urgency_pressure",
  "purpose_mismatch",
  "social_engineering",
  "lookalike_payee",
]);

const NETWORK_RULES: [RegExp, string][] = [
  [/\bethereum\b|эфириум/i, "ethereum"],
  [/\bbase\b/i, "base"],
  [/\bsolana\b/i, "solana"],
];

function unique(values: string[]): string[] {
  return [...new Set(values)];
}

function networksIn(text: string): string[] {
  return unique(NETWORK_RULES.filter(([rule]) => rule.test(text)).map(([, name]) => name));
}

function assetsIn(text: string): string[] {
  return unique([...text.matchAll(/\b(usdc|usdt|dai)\b/gi)].map((match) => match[1].toUpperCase()));
}

function evmAddresses(text: string): string[] {
  return unique([...text.matchAll(/\b0x[a-fA-F0-9]{40}\b/g)].map((match) => match[0]));
}

function solanaAddresses(text: string): string[] {
  return unique(
    [...text.matchAll(/\b[1-9A-HJ-NP-Za-km-z]{32,44}\b/g)]
      .map((match) => match[0])
      .filter((value) => !/^0x/i.test(value)),
  );
}

function amountsIn(text: string): string[] {
  const stripped = text
    .replace(/0x[a-fA-F0-9]{40}/g, " ")
    .replace(/\b[1-9A-HJ-NP-Za-km-z]{32,44}\b/g, " ");
  const found: string[] = [];
  const patterns = [
    /(\d{1,9}(?:[.,]\d{1,8})?)\s*(?:usdc|usd)\b/gi,
    /\b(?:usdc|usd)\s*(\d{1,9}(?:[.,]\d{1,8})?)/gi,
    /\$\s*(\d{1,9}(?:[.,]\d{1,8})?)/gi,
  ];
  for (const pattern of patterns) {
    for (const match of stripped.matchAll(pattern)) {
      found.push(match[1].replace(",", "."));
    }
  }
  const parsed = found
    .map((value) => ({ value, units: parseUnits(value) }))
    .filter((item) => item.units !== null);
  const distinct: string[] = [];
  for (const item of parsed) {
    if (!distinct.some((have) => sameUnits(have, item.value))) distinct.push(item.value);
  }
  return distinct;
}

export function extractLocal(text: string): LocalExtract {
  const missing: string[] = [];
  const conflicts: string[] = [];
  const networks = networksIn(text);
  const assets = assetsIn(text);
  const amounts = amountsIn(text);
  const evm = evmAddresses(text);
  const sol = solanaAddresses(text);

  let network: string | undefined;
  if (networks.length === 1) network = networks[0];
  else if (networks.length > 1) conflicts.push("В тексте несколько сетей. Оставьте одну: Base, Ethereum или Solana.");
  else missing.push("Укажите сеть: Base, Ethereum или Solana.");

  let asset: string | undefined;
  if (assets.length === 1) asset = assets[0];
  else if (assets.length > 1) conflicts.push("В тексте несколько активов. Оставьте один.");
  else missing.push("Укажите актив. Политика Anna по умолчанию пропускает только USDC.");

  let amount: string | undefined;
  if (amounts.length === 1) {
    if (parseUnits(amounts[0]) === null) conflicts.push("Сумма не читается как USDC с точностью до 6 знаков.");
    else amount = amounts[0];
  } else if (amounts.length > 1) conflicts.push("В тексте несколько разных сумм. Оставьте одну.");
  else missing.push("Укажите сумму числом, например 25 USDC. Слова вроде «полтысячи» не принимаются.");

  let payee: string | undefined;
  const pool = network === "solana" ? sol : network === "base" || network === "ethereum" ? evm : [...evm, ...sol];
  if (network === "solana" && evm.length > 0) conflicts.push("Сеть Solana, но в тексте есть EVM-адрес.");
  if ((network === "base" || network === "ethereum") && sol.length > 0 && evm.length === 0) {
    conflicts.push("Сеть EVM, а адрес похож на Solana.");
  }
  if (pool.length === 1) payee = pool[0];
  else if (pool.length > 1) conflicts.push("В тексте несколько адресов. Оставьте одного получателя.");
  else missing.push("Укажите адрес получателя целиком.");

  return { network, asset, amount, payee, missing, conflicts };
}

function appears(text: string, value: string): boolean {
  return text.toLowerCase().includes(value.trim().toLowerCase());
}

function literalPayee(text: string, candidate: string): string | null {
  const escaped = candidate.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = text.match(new RegExp(escaped, "i"));
  return match ? match[0] : null;
}

const FLAG_DETAIL: Record<string, string> = {
  prompt_injection: "Модель видит попытку продавить ALLOW. На решение это не влияет.",
  urgency_pressure: "В запросе давление срочностью. Это повод для WARN, не для пропуска.",
  purpose_mismatch: "Назначение и платёж расходятся. Модель только поднимает проверку.",
  social_engineering: "Похоже на давление авторитетом. Политика от этого не мягче.",
  lookalike_payee: "Адрес похож на подмену. Сам по себе это не BLOCK.",
};

export function mergeExtract(text: string, local: LocalExtract, model: ModelRead | null): MergeResult {
  const rejected: string[] = [];
  const conflicts = [...local.conflicts];
  const missing = [...local.missing];
  let network = local.network;
  let asset = local.asset;
  let amount = local.amount;
  let payee = local.payee;

  const take = (field: "network" | "asset" | "amount" | "payee", value: string | null, have: string | undefined) => {
    if (!value || !value.trim()) return have;
    const clean = value.trim();
    if (field === "payee") {
      const literal = literalPayee(text, clean);
      if (!literal) {
        rejected.push(`Модель назвала адрес ${clean}, но этой строки в запросе нет.`);
        return have;
      }
      if (have && have.toLowerCase() !== literal.toLowerCase()) {
        conflicts.push("Модель и текст разошлись в адресе. Уточните получателя.");
        return have;
      }
      return have ?? literal;
    }
    if (field === "amount") {
      if (!appears(text, clean.replace(/\.0+$/, "")) && !appears(text, clean)) {
        const units = parseUnits(clean);
        const localUnits = have ? parseUnits(have) : null;
        if (units !== null && localUnits !== null && units === localUnits) return have;
        rejected.push(`Модель назвала сумму ${clean}, но в тексте её нет.`);
        return have;
      }
      if (have && !sameUnits(have, clean)) {
        conflicts.push("Модель и текст разошлись в сумме. Напишите одну цифру.");
        return have;
      }
      return have ?? clean;
    }
    const normalized = field === "asset" ? clean.toUpperCase() : clean.toLowerCase();
    if (!appears(text, normalized) && !(field === "network" && appears(text, clean))) {
      rejected.push(`Модель назвала ${field === "asset" ? "актив" : "сеть"} ${clean}, но в тексте этого нет.`);
      return have;
    }
    if (have && have.toLowerCase() !== normalized.toLowerCase()) {
      conflicts.push(
        field === "asset" ? "Модель и текст разошлись в активе." : "Модель и текст разошлись в сети.",
      );
      return have;
    }
    return have ?? normalized;
  };

  if (model) {
    network = take("network", model.network, network);
    asset = take("asset", model.asset, asset);
    amount = take("amount", model.amount, amount);
    payee = take("payee", model.payee, payee);
  }

  const questions = unique([...conflicts, ...missing.filter((item) => {
    if (item.startsWith("Укажите сеть") && network) return false;
    if (item.startsWith("Укажите актив") && asset) return false;
    if (item.startsWith("Укажите сумму") && amount) return false;
    if (item.startsWith("Укажите адрес") && payee) return false;
    return true;
  })]);

  const advisory: RuleHit[] = [];
  let ignoredModelBlock = false;
  if (model) {
    const requested = model.requestedDecision?.toUpperCase() ?? null;
    if (requested === "BLOCK" || requested === "ALLOW") {
      if (requested === "BLOCK") ignoredModelBlock = true;
    }
    for (const flag of model.riskFlags) {
      if (!FLAG_CODES.has(flag.code)) continue;
      advisory.push({
        code: flag.code,
        severity: "WARN",
        detail: FLAG_DETAIL[flag.code] ?? flag.detail.slice(0, 180),
      });
    }
    if (requested === "BLOCK") {
      advisory.push({
        code: "ignored_model_block",
        severity: "WARN",
        detail: "Модель просила BLOCK. Этот вердикт выброшен: запрещать может только политика.",
      });
      ignoredModelBlock = true;
    }
  }

  const complete = questions.length === 0 && Boolean(network && asset && amount && payee);
  return {
    complete,
    questions,
    rejected,
    intent: complete ? { network: network!, asset: asset!, amount: amount!, payee: payee! } : null,
    mode: model ? "ai" : "policy-only",
    advisory: model ? advisory : [],
    ignoredModelBlock: model ? ignoredModelBlock : false,
    modelRequested: model?.requestedDecision ?? null,
  };
}

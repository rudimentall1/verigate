import { formatUnits, parseUnits } from "./money.ts";

export type Decision = "ALLOW" | "WARN" | "BLOCK";
export type Severity = "WARN" | "BLOCK";

export type Policy = {
  payeeValidation: boolean;
  requirePositiveAmount: boolean;
  blockedPayees: string[];
  allowedPayees: string[] | null;
  allowedNetworks: string[];
  allowedAssets: string[];
  perTxCap: Record<string, string>;
  newPayeeCap: Record<string, string>;
  confirmationRequiredOver: Record<string, string>;
  dailyCap: Record<string, string>;
  rateLimitPerMinute: number;
};

/** Fresh-install policy shipped with Anna App 0.1.29 (`policies/anna.yaml`). */
export const ANNA_POLICY: Policy = {
  payeeValidation: true,
  requirePositiveAmount: true,
  blockedPayees: [],
  allowedPayees: null,
  allowedNetworks: ["base", "ethereum", "solana"],
  allowedAssets: ["USDC"],
  perTxCap: { USDC: "500" },
  newPayeeCap: { USDC: "50" },
  confirmationRequiredOver: { USDC: "250" },
  dailyCap: { USDC: "2000" },
  rateLimitPerMinute: 30,
};

export type RuleHit = {
  code: string;
  severity: Severity;
  detail: string;
};

export type Intent = {
  network: string;
  asset: string;
  amount: string;
  payee: string;
};

export type HistoryView = {
  spentUnits: bigint;
  payeeSeen: boolean;
  attemptsLastMinute: number;
};

export function emptyHistory(): HistoryView {
  return { spentUnits: 0n, payeeSeen: false, attemptsLastMinute: 0 };
}

function capUnits(table: Record<string, string>, asset: string): bigint | null {
  const raw = table[asset.toUpperCase()];
  if (raw === undefined) return null;
  return parseUnits(raw);
}

export function payeeProblem(payee: string, network: string): string | null {
  const value = payee.trim();
  if (!value) return "Адрес пустой.";
  const net = network.trim().toLowerCase();
  if (net === "base" || net === "ethereum") {
    return /^0x[a-fA-F0-9]{40}$/.test(value)
      ? null
      : "Для Base и Ethereum нужен адрес 0x и 40 hex-символов.";
  }
  if (net === "solana") {
    return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(value)
      ? null
      : "Для Solana нужен base58-адрес получателя.";
  }
  return "Сеть не из списка, формат адреса не к чему приложить.";
}

function sortedRecord(table: Record<string, string>): Record<string, string> {
  return Object.fromEntries(
    Object.entries(table)
      .map(([key, value]) => [key.toUpperCase(), value.trim()] as const)
      .sort(([a], [b]) => a.localeCompare(b)),
  );
}

/** Stable document. The receipt binds to the hash of this string. */
export function policyCanonical(policy: Policy): string {
  const document = {
    allowed_assets: [...policy.allowedAssets].map((item) => item.toUpperCase()).sort(),
    allowed_networks: [...policy.allowedNetworks].map((item) => item.toLowerCase()).sort(),
    allowed_payees: policy.allowedPayees
      ? [...policy.allowedPayees].map((item) => item.toLowerCase()).sort()
      : null,
    blocked_payees: [...policy.blockedPayees].map((item) => item.toLowerCase()).sort(),
    confirmation_required_over: sortedRecord(policy.confirmationRequiredOver),
    daily_cap: sortedRecord(policy.dailyCap),
    new_payee_cap: sortedRecord(policy.newPayeeCap),
    payee_validation: policy.payeeValidation,
    per_tx_cap: sortedRecord(policy.perTxCap),
    rate_limit_per_minute: policy.rateLimitPerMinute,
    require_positive_amount: policy.requirePositiveAmount,
  };
  return JSON.stringify(document);
}

/**
 * Same order and severity as `GuardrailEngine` for a payment intent.
 * Advisory input may only add WARN. A model BLOCK is dropped here.
 */
export function evaluate(
  intent: Intent,
  policy: Policy,
  history: HistoryView,
  advisory: readonly RuleHit[] = [],
): { decision: Decision; rules: RuleHit[] } {
  const rules: RuleHit[] = [];
  const asset = intent.asset.toUpperCase();
  const network = intent.network.toLowerCase();
  const payee = intent.payee.trim();
  const amount = parseUnits(intent.amount);

  if (policy.payeeValidation) {
    const problem = payeeProblem(payee, network);
    if (problem) rules.push({ code: "payee_format", severity: "BLOCK", detail: problem });
  }

  if (policy.requirePositiveAmount && (amount === null || amount <= 0n)) {
    rules.push({
      code: "invalid_amount",
      severity: "BLOCK",
      detail: "Сумма должна быть больше нуля и не длиннее 6 знаков после запятой.",
    });
  }

  const blocked = new Set(policy.blockedPayees.map((item) => item.toLowerCase()));
  if (payee && blocked.has(payee.toLowerCase())) {
    rules.push({
      code: "blocked_payee",
      severity: "BLOCK",
      detail: "Получатель в списке запрещённых. Это BLOCK, его не подтверждают.",
    });
  }

  if (policy.allowedPayees && !policy.allowedPayees.map((item) => item.toLowerCase()).includes(payee.toLowerCase())) {
    rules.push({
      code: "payee_not_allowlisted",
      severity: "BLOCK",
      detail: "Включён режим списка. Этого адреса в нём нет.",
    });
  }

  if (
    policy.allowedNetworks.length > 0 &&
    !policy.allowedNetworks.map((item) => item.toLowerCase()).includes(network)
  ) {
    rules.push({
      code: "network_not_allowed",
      severity: "BLOCK",
      detail: `Сеть ${network || "—"} не разрешена. Сейчас: ${policy.allowedNetworks.join(", ")}.`,
    });
  }

  if (policy.allowedAssets.length > 0 && !policy.allowedAssets.map((item) => item.toUpperCase()).includes(asset)) {
    rules.push({
      code: "asset_not_allowed",
      severity: "BLOCK",
      detail: `Актив ${asset || "—"} не разрешён. Сейчас только ${policy.allowedAssets.join(", ")}.`,
    });
  }

  const perTx = capUnits(policy.perTxCap, asset);
  if (amount !== null && perTx !== null && amount > perTx) {
    rules.push({
      code: "per_tx_cap_exceeded",
      severity: "BLOCK",
      detail: `Жёсткий потолок одной транзакции — ${formatUnits(perTx)} ${asset}. Человек его не снимает.`,
    });
  }

  const firstCap = capUnits(policy.newPayeeCap, asset);
  if (amount !== null && firstCap !== null && !history.payeeSeen && amount > firstCap) {
    rules.push({
      code: "new_payee_cap_exceeded",
      severity: "WARN",
      detail: `Первое разрешение этому адресу выше ${formatUnits(firstCap)} ${asset}. Это WARN, не запрет.`,
    });
  }

  const daily = capUnits(policy.dailyCap, asset);
  if (amount !== null && daily !== null && (amount <= 0n || history.spentUnits + amount > daily)) {
    rules.push({
      code: "daily_cap_exceeded",
      severity: "BLOCK",
      detail: `Вместе с резервом 24 часов (${formatUnits(history.spentUnits)} ${asset}) это выше ${formatUnits(daily)} ${asset}.`,
    });
  }

  const reviewOver = capUnits(policy.confirmationRequiredOver, asset);
  if (amount !== null && reviewOver !== null && amount > reviewOver) {
    rules.push({
      code: "confirmation_required",
      severity: "WARN",
      detail: `Сумма выше ${formatUnits(reviewOver)} ${asset}. Нужен отдельный просмотр предупреждений.`,
    });
  }

  if (policy.rateLimitPerMinute > 0 && history.attemptsLastMinute >= policy.rateLimitPerMinute) {
    rules.push({
      code: "rate_limit_exceeded",
      severity: "BLOCK",
      detail: `${policy.rateLimitPerMinute} записанных попыток за минуту. Это остановка цикла, не совет модели.`,
    });
  }

  for (const flag of advisory) {
    if (flag.severity === "WARN") rules.push(flag);
  }

  const decision: Decision = rules.some((rule) => rule.severity === "BLOCK")
    ? "BLOCK"
    : rules.some((rule) => rule.severity === "WARN")
      ? "WARN"
      : "ALLOW";

  return { decision, rules };
}

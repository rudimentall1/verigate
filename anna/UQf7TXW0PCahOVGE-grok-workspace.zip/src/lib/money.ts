const SCALE = 6n;
const BASE = 10n ** SCALE;

/** Parse a USDC decimal. `null` if it is not a finite non-negative decimal with ≤6 places. */
export function parseUnits(input: string): bigint | null {
  const s = input.trim().replace(/\s/g, "").replace(",", ".");
  if (!/^\d+(\.\d+)?$/.test(s)) return null;
  const [whole, frac = ""] = s.split(".");
  if (frac.length > 6) return null;
  if (whole.length > 1 && whole.startsWith("0")) return null;
  try {
    return BigInt(whole) * BASE + BigInt((frac + "000000").slice(0, 6));
  } catch {
    return null;
  }
}

export function formatUnits(units: bigint): string {
  const neg = units < 0n;
  const v = neg ? -units : units;
  const whole = v / BASE;
  const frac = (v % BASE).toString().padStart(6, "0").replace(/0+$/, "");
  const text = frac ? `${whole.toString()}.${frac}` : whole.toString();
  return neg ? `-${text}` : text;
}

export function sameUnits(a: string, b: string): boolean {
  const pa = parseUnits(a);
  const pb = parseUnits(b);
  return pa !== null && pb !== null && pa === pb;
}

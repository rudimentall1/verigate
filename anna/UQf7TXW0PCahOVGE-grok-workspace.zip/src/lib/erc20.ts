import { parseUnits } from "./money.ts";

/** Circle native USDC. Public contract addresses, not secrets. */
export const USDC: Record<"base" | "ethereum", { chainId: string; token: string; chainName: string }> = {
  base: {
    chainId: "0x2105",
    token: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
    chainName: "Base",
  },
  ethereum: {
    chainId: "0x1",
    token: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
    chainName: "Ethereum",
  },
};

export function transferCalldata(payee: string, amount: string): string | null {
  if (!/^0x[a-fA-F0-9]{40}$/.test(payee)) return null;
  const units = parseUnits(amount);
  if (units === null) return null;
  const selector = "a9059cbb";
  const address = payee.slice(2).toLowerCase().padStart(64, "0");
  const value = units.toString(16).padStart(64, "0");
  return `0x${selector}${address}${value}`;
}

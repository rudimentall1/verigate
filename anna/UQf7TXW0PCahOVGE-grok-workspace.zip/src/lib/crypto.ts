function bytesToB64(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function b64ToBuf(value: string): ArrayBuffer {
  const binary = atob(value);
  const buffer = new ArrayBuffer(binary.length);
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return buffer;
}

export function bytesToHex(bytes: Uint8Array): string {
  return [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function sha256Hex(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return bytesToHex(new Uint8Array(digest));
}

export type IssuerKey = {
  publicRawB64: string;
  privatePkcs8B64: string;
  fingerprint: string;
  publicHex: string;
};

function formatFingerprint(hex: string): string {
  return hex
    .slice(0, 16)
    .toUpperCase()
    .replace(/(.{4})/g, "$1·")
    .replace(/·$/, "");
}

export async function createIssuer(): Promise<IssuerKey> {
  const pair = await crypto.subtle.generateKey({ name: "Ed25519" }, true, ["sign", "verify"]);
  const raw = new Uint8Array(await crypto.subtle.exportKey("raw", pair.publicKey));
  const pkcs8 = new Uint8Array(await crypto.subtle.exportKey("pkcs8", pair.privateKey));
  const digest = await crypto.subtle.digest("SHA-256", raw);
  return {
    publicRawB64: bytesToB64(raw),
    privatePkcs8B64: bytesToB64(pkcs8),
    publicHex: bytesToHex(raw),
    fingerprint: formatFingerprint(bytesToHex(new Uint8Array(digest))),
  };
}

async function privateKey(pkcs8B64: string): Promise<CryptoKey> {
  return crypto.subtle.importKey("pkcs8", b64ToBuf(pkcs8B64), { name: "Ed25519" }, false, ["sign"]);
}

async function publicKey(rawB64: string): Promise<CryptoKey> {
  return crypto.subtle.importKey("raw", b64ToBuf(rawB64), { name: "Ed25519" }, true, ["verify"]);
}

export async function signText(pkcs8B64: string, text: string): Promise<string> {
  const signature = await crypto.subtle.sign({ name: "Ed25519" }, await privateKey(pkcs8B64), new TextEncoder().encode(text));
  return bytesToB64(new Uint8Array(signature));
}

export async function verifyText(rawB64: string, text: string, signatureB64: string): Promise<boolean> {
  return crypto.subtle.verify(
    { name: "Ed25519" },
    await publicKey(rawB64),
    b64ToBuf(signatureB64),
    new TextEncoder().encode(text),
  );
}

export function canonicalize(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map((item) => canonicalize(item)).join(",")}]`;
  const entries = Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b));
  return `{${entries.map(([key, item]) => `${JSON.stringify(key)}:${canonicalize(item)}`).join(",")}}`;
}

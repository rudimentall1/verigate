import { canonicalize } from "./crypto.ts";
import { parseUnits } from "./money.ts";
import type { Decision, HistoryView, Intent, RuleHit } from "./policy.ts";

export type Mode = "ai" | "policy-only";

export type LedgerRecord = {
  id: string;
  createdAt: number;
  exp: number | null;
  consumedAt: number | null;
  releasedAt: number | null;
  decision: Decision;
  mode: Mode;
  network: string;
  asset: string;
  amount: string;
  payee: string;
  rules: RuleHit[];
  policyDigest: string;
  decisionCanonical: string;
  decisionSig: string;
  executionCanonical: string | null;
  executionSig: string | null;
  nonce: string | null;
  walletNote: string | null;
  ignoredModelBlock: boolean;
};

const DAY = 24 * 60 * 60 * 1000;
const MINUTE = 60 * 1000;

export function spentUnits(records: readonly LedgerRecord[], asset: string, now: number): bigint {
  return records.reduce((sum, record) => {
    if (record.asset.toUpperCase() !== asset.toUpperCase()) return sum;
    if (record.decision === "BLOCK" || !record.executionSig || record.releasedAt !== null) return sum;
    if (now - record.createdAt > DAY) return sum;
    const units = parseUnits(record.amount);
    return units === null ? sum : sum + units;
  }, 0n);
}

export function historyFor(
  records: readonly LedgerRecord[],
  attempts: readonly { at: number }[],
  asset: string,
  payee: string,
  now: number,
): HistoryView {
  const needle = payee.toLowerCase();
  return {
    spentUnits: spentUnits(records, asset, now),
    payeeSeen: records.some(
      (record) =>
        record.payee.toLowerCase() === needle && record.decision !== "BLOCK" && record.executionSig !== null,
    ),
    attemptsLastMinute: attempts.filter((attempt) => now - attempt.at < MINUTE).length,
  };
}

export function issueCanonical(intent: Intent, ruleCodes: readonly string[]): string {
  return canonicalize({
    amount: intent.amount,
    asset: intent.asset.toUpperCase(),
    network: intent.network.toLowerCase(),
    payee: intent.payee,
    purpose: "issue",
    rules: [...ruleCodes].sort(),
  });
}

export function submitCanonical(record: Pick<LedgerRecord, "nonce" | "payee" | "amount" | "network" | "asset">): string {
  return canonicalize({
    amount: record.amount,
    asset: record.asset.toUpperCase(),
    network: record.network.toLowerCase(),
    nonce: record.nonce,
    payee: record.payee,
    purpose: "submit",
  });
}

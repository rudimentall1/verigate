import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "@/components/shell";
import { sha256Hex } from "@/lib/crypto";
import { parseUnits, formatUnits } from "@/lib/money";
import { ANNA_POLICY, policyCanonical } from "@/lib/policy";
import { useDesk } from "@/lib/store";

export const Route = createFileRoute("/policy")({ component: PolicyPage });

function PolicyPage() {
  const policy = useDesk((state) => state.policy);
  const setPolicy = useDesk((state) => state.setPolicy);
  const resetPolicy = useDesk((state) => state.resetPolicy);
  const [digest, setDigest] = useState("");
  const [payee, setPayee] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void sha256Hex(policyCanonical(policy)).then(setDigest);
  }, [policy]);

  function commitCap(key: "perTxCap" | "newPayeeCap" | "confirmationRequiredOver" | "dailyCap", raw: string) {
    const units = parseUnits(raw);
    if (units === null || units <= 0n) {
      setError("Лимит должен быть суммой USDC больше нуля, не длиннее 6 знаков.");
      return;
    }
    setError(null);
    setPolicy({ ...policy, [key]: { ...policy[key], USDC: formatUnits(units) } });
  }

  return (
    <Shell>
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold">Политика</h2>
          <p className="mt-1 max-w-2xl text-sm text-ink-soft">
            Старт — цифры Anna 0.1.29. Смена лимита меняет отпечаток, старые чеки остаются привязаны к старому.
          </p>
        </div>
        <button type="button" className="min-h-11 rounded-md border border-line px-3 text-sm" onClick={() => resetPolicy()}>
          Вернуть 0.1.29
        </button>
      </div>
      <p className="mt-4 break-all font-mono text-xs text-ink-soft">digest {digest || "считается"}</p>
      {error ? <p className="mt-2 text-sm text-block">{error}</p> : null}

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <Cap label="Потолок транзакции, USDC" value={policy.perTxCap.USDC ?? ""} onCommit={(value) => commitCap("perTxCap", value)} />
        <Cap label="Первый адрес, WARN выше" value={policy.newPayeeCap.USDC ?? ""} onCommit={(value) => commitCap("newPayeeCap", value)} />
        <Cap
          label="Просмотр человека выше"
          value={policy.confirmationRequiredOver.USDC ?? ""}
          onCommit={(value) => commitCap("confirmationRequiredOver", value)}
        />
        <Cap label="Бюджет 24 часов" value={policy.dailyCap.USDC ?? ""} onCommit={(value) => commitCap("dailyCap", value)} />
        <Cap
          label="Попыток в минуту"
          value={String(policy.rateLimitPerMinute)}
          onCommit={(value) => {
            const rate = Number(value);
            if (!Number.isInteger(rate) || rate < 1 || rate > 120) {
              setError("Частота — целое от 1 до 120.");
              return;
            }
            setError(null);
            setPolicy({ ...policy, rateLimitPerMinute: rate });
          }}
        />
      </div>

      <section className="mt-6 border border-line bg-card p-4">
        <h3 className="font-semibold">Запрещённые адреса</h3>
        <p className="mt-1 text-sm text-ink-soft">Совпадение точное, без регистра. Формат здесь не проверяется: блок — это список, не догадка.</p>
        <form
          className="mt-3 flex flex-col gap-2 sm:flex-row"
          onSubmit={(event) => {
            event.preventDefault();
            const next = payee.trim();
            if (!next) return;
            if (policy.blockedPayees.some((item) => item.toLowerCase() === next.toLowerCase())) {
              setPayee("");
              return;
            }
            setPolicy({ ...policy, blockedPayees: [...policy.blockedPayees, next] });
            setPayee("");
          }}
        >
          <input
            value={payee}
            onChange={(event) => setPayee(event.target.value)}
            placeholder="0x… или адрес Solana"
            className="field font-mono text-sm"
            aria-label="Адрес в запрет"
          />
          <button type="submit" className="min-h-11 rounded-md bg-ink px-4 text-sm font-medium text-paper">
            Запретить
          </button>
        </form>
        <ul className="mt-3 space-y-2">
          {policy.blockedPayees.length === 0 ? <li className="text-sm text-ink-soft">Список пуст, как в поставке.</li> : null}
          {policy.blockedPayees.map((item) => (
            <li key={item} className="flex items-center justify-between gap-3 text-sm">
              <span className="break-all font-mono text-xs">{item}</span>
              <button
                type="button"
                className="min-h-11 shrink-0 text-sm text-copper"
                onClick={() =>
                  setPolicy({ ...policy, blockedPayees: policy.blockedPayees.filter((payeeItem) => payeeItem !== item) })
                }
              >
                Убрать
              </button>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-4 border border-line bg-card p-4">
        <label className="flex min-h-11 items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={policy.allowedPayees !== null}
            onChange={(event) =>
              setPolicy({
                ...policy,
                allowedPayees: event.target.checked ? (policy.allowedPayees ?? []) : null,
              })
            }
          />
          Пускать только адреса из списка
        </label>
        {policy.allowedPayees ? (
          <Allowlist
            items={policy.allowedPayees}
            onChange={(allowedPayees) => setPolicy({ ...policy, allowedPayees })}
          />
        ) : (
          <p className="mt-2 text-sm text-ink-soft">Выключено: годится любой адрес, которого нет в запрете и который проходит формат сети.</p>
        )}
      </section>
      <p className="mt-4 text-xs text-ink-soft">Сети {ANNA_POLICY.allowedNetworks.join(", ")} · актив USDC. Их состав в этой кассе не расширяется.</p>
    </Shell>
  );
}

function Cap({ label, value, onCommit }: { label: string; value: string; onCommit: (value: string) => void }) {
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  return (
    <label className="block text-sm">
      {label}
      <input
        className="field mt-1 font-mono"
        inputMode="decimal"
        value={text}
        onChange={(event) => setText(event.target.value)}
        onBlur={() => onCommit(text)}
      />
    </label>
  );
}

function Allowlist({ items, onChange }: { items: string[]; onChange: (items: string[]) => void }) {
  const [text, setText] = useState("");
  return (
    <div className="mt-3">
      <form
        className="flex flex-col gap-2 sm:flex-row"
        onSubmit={(event) => {
          event.preventDefault();
          const next = text.trim();
          if (!next) return;
          if (!items.some((item) => item.toLowerCase() === next.toLowerCase())) onChange([...items, next]);
          setText("");
        }}
      >
        <input value={text} onChange={(event) => setText(event.target.value)} className="field font-mono text-sm" aria-label="Адрес в список" />
        <button type="submit" className="min-h-11 rounded-md border border-line px-4 text-sm">
          Добавить
        </button>
      </form>
      {items.length === 0 ? <p className="mt-2 text-sm text-block">Список пуст, поэтому сейчас не пройдёт ни один адрес.</p> : null}
      <ul className="mt-2 space-y-2">
        {items.map((item) => (
          <li key={item} className="flex items-center justify-between gap-3">
            <span className="break-all font-mono text-xs">{item}</span>
            <button type="button" className="min-h-11 text-sm text-copper" onClick={() => onChange(items.filter((payee) => payee !== item))}>
              Убрать
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

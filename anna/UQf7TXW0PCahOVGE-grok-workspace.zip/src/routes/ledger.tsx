import { createFileRoute } from "@tanstack/react-router";
import { Shell, useNow } from "@/components/shell";
import { historyFor, spentUnits, type LedgerRecord } from "@/lib/ledger";
import { formatUnits, parseUnits } from "@/lib/money";
import { ANNA_POLICY } from "@/lib/policy";
import { useDesk } from "@/lib/store";

export const Route = createFileRoute("/ledger")({ component: LedgerPage });

function status(record: LedgerRecord): string {
  if (record.decision === "BLOCK" || !record.executionSig) return "попытка без полномочия";
  if (record.releasedAt) return "резерв снят";
  if (record.consumedAt) return "разрешение использовано";
  if (record.exp !== null && record.exp < Date.now()) return "разрешение истекло";
  return "резерв держится";
}

function LedgerPage() {
  const records = useDesk((state) => state.records);
  const attempts = useDesk((state) => state.attempts);
  const policy = useDesk((state) => state.policy);
  const now = useNow(true);
  const moment = now ?? 0;
  const spentRaw = spentUnits(records, "USDC", moment);
  const spent = formatUnits(spentRaw);
  const cap = policy.dailyCap.USDC ?? ANNA_POLICY.dailyCap.USDC;
  const pace = historyFor(records, attempts, "USDC", "", moment).attemptsLastMinute;
  const capUnits = cap ? parseUnits(cap) : null;
  const width = capUnits && capUnits > 0n ? Math.min(100, Number((spentRaw * 100n) / capUnits)) : 0;

  return (
    <Shell>
      <h2 className="text-lg font-semibold">Журнал установки</h2>
      <p className="mt-1 max-w-2xl text-sm text-ink-soft">
        В бюджет попадают только выпущенные разрешения, не превью и не BLOCK. Снятие резерва остаётся в журнале.
        Это локальная касса, не сеть.
      </p>
      <div className="mt-4 border border-line bg-card p-4">
        <div className="flex items-baseline justify-between gap-3 text-sm">
          <p className="font-mono tabular-nums">
            {spent} / {cap} USDC
          </p>
          <p className="text-ink-soft">попыток за минуту {now ? pace : "—"} / {policy.rateLimitPerMinute}</p>
        </div>
        <div className="mt-3 h-2 bg-paper">
          <div className="h-2 bg-copper" style={{ width: `${width}%` }} />
        </div>
      </div>
      {records.length === 0 ? (
        <p className="mt-6 text-sm text-ink-soft">Пока пусто. Проверка без подтверждения сюда не пишется.</p>
      ) : (
        <ul className="mt-4 divide-y divide-line border border-line bg-card">
          {records.map((record) => (
            <li key={record.id} className="flex flex-col gap-2 px-3 py-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="font-mono text-sm">
                  {record.decision} · {record.amount} {record.asset} · {record.network}
                </p>
                <p className="break-all font-mono text-xs text-ink-soft">{record.payee}</p>
                <p className="text-xs text-ink-soft">
                  {new Date(record.createdAt).toLocaleString("ru-RU")} · {status(record)}
                </p>
                {record.walletNote ? <p className="mt-1 text-sm">{record.walletNote}</p> : null}
              </div>
              {record.executionSig && record.decision !== "BLOCK" && !record.releasedAt ? (
                <button
                  type="button"
                  className="min-h-11 shrink-0 rounded-md border border-line px-3 text-sm"
                  onClick={() => useDesk.getState().release(record.id)}
                >
                  Снять резерв
                </button>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </Shell>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell } from "@/components/shell";
import { FINDINGS, LINK_GROUPS, MATRIX, SOURCE, auditMarkdown } from "@/lib/audit-data";
import { cn } from "@/lib/cn";
import { runConformance, type ConformanceCheck } from "@/lib/conformance";
import { canonicalize, signText, verifyText } from "@/lib/crypto";
import { useDesk } from "@/lib/store";

export const Route = createFileRoute("/audit")({ component: AuditPage });

const STATE_CLASS = {
  проверено: "text-allow",
  частично: "text-warn",
  нет: "text-block",
  "не утверждать": "text-block",
} as const;

function download(name: string, text: string, type: string) {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}

function AuditPage() {
  const fingerprint = useDesk((state) => state.issuer?.fingerprint ?? null);
  const [copied, setCopied] = useState(false);
  const [checks, setChecks] = useState<ConformanceCheck[] | null>(null);
  const [signature, setSignature] = useState<"idle" | "ok" | "bad" | "nokey">("idle");
  const [running, setRunning] = useState(false);

  const failed = checks?.filter((check) => !check.pass).length ?? 0;
  const passed = checks ? checks.length - failed : 0;

  async function run() {
    setRunning(true);
    const list = runConformance();
    setChecks(list);
    const issuer = useDesk.getState().issuer;
    if (!issuer) {
      setSignature("nokey");
      setRunning(false);
      return;
    }
    const body = canonicalize({ kind: "conformance-probe", v: 1, amount: "25", decision: "ALLOW" });
    const signed = await signText(issuer.privatePkcs8B64, body);
    const intact = await verifyText(issuer.publicRawB64, body, signed);
    const tampered = await verifyText(issuer.publicRawB64, `${body} `, signed);
    setSignature(intact && !tampered ? "ok" : "bad");
    setRunning(false);
  }

  function evidence() {
    const payload = {
      product: "Verigate Authority desk",
      comparesTo: "Anna App immutable Draft 0.1.29 policy numbers",
      not: "Not the Python Executa, not a chain payment, not marketplace publication.",
      fingerprint,
      signature:
        signature === "ok"
          ? "Ed25519 probe verified; a one-byte tamper failed verification."
          : signature,
      passed,
      failed,
      checks,
    };
    download("anna-desk-conformance.json", JSON.stringify(payload, null, 2), "application/json");
  }

  return (
    <Shell>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="font-mono text-xs tracking-widest text-copper">ПАКЕТ ДЛЯ АУДИТА</p>
          <h2 className="mt-1 text-lg font-semibold">Только Anna, не весь Verigate</h2>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <button
            type="button"
            className="min-h-11 rounded-md border border-line px-4 text-sm"
            onClick={() => download("anna-audit-brief.md", auditMarkdown(), "text/markdown")}
          >
            Скачать бриф
          </button>
          <button
            type="button"
            className="min-h-11 rounded-md bg-ink px-4 text-sm font-medium text-paper"
          onClick={() => {
            void navigator.clipboard.writeText(auditMarkdown()).then(
              () => setCopied(true),
              () => setCopied(false),
            );
          }}
        >
          {copied ? "Скопировано" : "Скопировать бриф"}
          </button>
        </div>
      </div>
      <p className="mt-3 max-w-3xl text-sm text-ink-soft">
        Это текст, который можно отдать проверяющим вместе со ссылками. Видео MetaMask от 9 ноября в репозитории нет:
        оно подтверждает кошелёк и сожжённое разрешение, но не завершённый платёж. Передавать ролик отдельно.
      </p>
      <p className="mt-3 text-sm">
        Первая ссылка:{" "}
        <a className="text-copper break-all" href={SOURCE}>
          {SOURCE}
        </a>
      </p>

      <section className="mt-6 border border-line bg-card p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h3 className="font-semibold">Сверка на этом устройстве</h3>
            <p className="mt-1 max-w-2xl text-sm text-ink-soft">
              Те же цифры, что в политике 0.1.29: потолок 500, новый адрес 50, просмотр свыше 250, бюджет 2000,
              30 попыток в минуту. Ключ установки подписывает пробный чек. Журнал и бюджет не меняются.
            </p>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <button
              type="button"
              onClick={() => void run()}
              disabled={running}
              className="min-h-11 rounded-md bg-copper px-4 text-sm font-medium text-paper disabled:opacity-50"
            >
              {running ? "Сверяю" : "Прогнать"}
            </button>
            <button
              type="button"
              onClick={evidence}
              disabled={!checks}
              className="min-h-11 rounded-md border border-line px-4 text-sm disabled:opacity-50"
            >
              Скачать свидетельство
            </button>
          </div>
        </div>
        {checks ? (
          <>
            <p className="mt-4 font-mono text-sm tabular-nums">
              {passed} сошлось
              {failed > 0 ? <span className="text-block"> · {failed} разошлось</span> : null}
              <span className="text-ink-soft">
                {" "}
                · подпись {signature === "ok" ? "сходится, подмена нет" : signature === "bad" ? "не сошлась" : signature === "nokey" ? "ключа ещё нет" : "—"}
                {fingerprint ? ` · ${fingerprint}` : ""}
              </span>
            </p>
            <ul className="mt-3 divide-y divide-line border-t border-line">
              {checks.map((check) => (
                <li key={check.id} className="grid gap-1 py-2 sm:grid-cols-[1.4rem_1fr_auto] sm:items-baseline sm:gap-3">
                  <span className={cn("font-mono text-xs", check.pass ? "text-allow" : "text-block")}>{check.pass ? "да" : "нет"}</span>
                  <span className="text-sm">{check.title}</span>
                  <span className="font-mono text-xs text-ink-soft sm:text-right">
                    {check.pass ? check.expect : `${check.expect} → ${check.actual}`}
                  </span>
                </li>
              ))}
            </ul>
          </>
        ) : (
          <p className="mt-4 text-sm text-ink-soft">Пока не запускалось. Это сверка кассы, не отчёт по репозиторию anna/.</p>
        )}
      </section>

      <section className="mt-6 border border-block bg-block-bg p-4 text-block">
        <h3 className="font-semibold">Что реально решает грант</h3>
        <p className="mt-2 text-sm">
          У программы Anna AI App Builder нет жюри и призовых мест. Платят за опубликованное приложение и 200
          квалифицированных MAU за один месяц сентября, октября или ноября 2026. Репозиторий, эта касса и демо-ролик
          заявкой не являются. App 851 до сих пор Draft: review версии 0.1.29 не отправлен.
        </p>
      </section>

      <section className="mt-6">
        <h3 className="font-semibold">Вердикт</h3>
        <p className="mt-2 max-w-3xl text-sm">
          Архитектуру менять не нужно. Граница верная: модель советует, политика решает, кошелёк подписывает. Дальше —
          отправить 0.1.29 на review, не обещать в карточке перевод Solana, вернуть резерв, если подпись отклонена, и
          оставить на первом экране готовые примеры. Универсальный файрвол для действий в обход ExecutionRouter обещать
          нельзя: его нет.
        </p>
      </section>

      <section className="mt-6">
        <h3 className="font-semibold">Наблюдения</h3>
        <p className="mt-1 text-sm text-ink-soft">Это не отчёт аудитора. Это чтение release status, anna.yaml и движка.</p>
        <ul className="mt-3 space-y-3">
          {FINDINGS.map((finding) => (
            <li key={finding.title} className="border border-line bg-card p-3">
              <p className="font-mono text-xs text-copper">{finding.severity}</p>
              <p className="mt-1 font-medium">{finding.title}</p>
              <p className="mt-1 text-sm text-ink-soft">{finding.detail}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-6 overflow-x-auto">
        <h3 className="font-semibold">Матрица</h3>
        <table className="mt-3 w-full min-w-[36rem] border-collapse text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs text-ink-soft">
              <th className="py-2 pr-3 font-medium">Способность</th>
              <th className="py-2 pr-3 font-medium">Сейчас</th>
              <th className="py-2 font-medium">Граница</th>
            </tr>
          </thead>
          <tbody>
            {MATRIX.map((row) => (
              <tr key={row.capability} className="border-b border-line align-top">
                <td className="py-2 pr-3">{row.capability}</td>
                <td className={cn("py-2 pr-3 font-mono text-xs", STATE_CLASS[row.state])}>{row.state}</td>
                <td className="py-2 text-ink-soft">{row.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {LINK_GROUPS.map((group) => (
          <section key={group.title} className="border border-line bg-card p-4">
            <h3 className="font-semibold">{group.title}</h3>
            <ul className="mt-2 space-y-1 text-sm">
              {group.links.map((link) => (
                <li key={link.href}>
                  <a className="text-copper break-all" href={link.href}>
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </Shell>
  );
}

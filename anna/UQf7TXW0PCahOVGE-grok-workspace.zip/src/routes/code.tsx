import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell } from "@/components/shell";
import { cn } from "@/lib/cn";
import desk from "@/components/desk.tsx?raw";
import auditRoute from "@/routes/audit.tsx?raw";
import ledgerRoute from "@/routes/ledger.tsx?raw";
import policyRoute from "@/routes/policy.tsx?raw";
import auditData from "@/lib/audit-data.ts?raw";
import conformance from "@/lib/conformance.ts?raw";
import cryptoSource from "@/lib/crypto.ts?raw";
import erc20 from "@/lib/erc20.ts?raw";
import examples from "@/lib/examples.ts?raw";
import extract from "@/lib/extract.ts?raw";
import interpret from "@/lib/interpret.ts?raw";
import ledger from "@/lib/ledger.ts?raw";
import money from "@/lib/money.ts?raw";
import policy from "@/lib/policy.ts?raw";
import store from "@/lib/store.ts?raw";

export const Route = createFileRoute("/code")({ component: CodePage });

const FILES = [
  { name: "src/components/desk.tsx", body: desk },
  { name: "src/lib/policy.ts", body: policy },
  { name: "src/lib/extract.ts", body: extract },
  { name: "src/lib/crypto.ts", body: cryptoSource },
  { name: "src/lib/ledger.ts", body: ledger },
  { name: "src/lib/store.ts", body: store },
  { name: "src/lib/conformance.ts", body: conformance },
  { name: "src/lib/money.ts", body: money },
  { name: "src/lib/erc20.ts", body: erc20 },
  { name: "src/lib/examples.ts", body: examples },
  { name: "src/lib/interpret.ts", body: interpret },
  { name: "src/lib/audit-data.ts", body: auditData },
  { name: "src/routes/audit.tsx", body: auditRoute },
  { name: "src/routes/policy.tsx", body: policyRoute },
  { name: "src/routes/ledger.tsx", body: ledgerRoute },
] as const;

function CodePage() {
  const [name, setName] = useState<(typeof FILES)[number]["name"]>(FILES[0].name);
  const [copied, setCopied] = useState(false);
  const file = FILES.find((item) => item.name === name) ?? FILES[0];

  return (
    <Shell>
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="font-mono text-xs tracking-widest text-copper">ИСХОДНИКИ КАССЫ</p>
          <h2 className="mt-1 text-lg font-semibold">Код, который рисует это превью</h2>
        </div>
        <button
          type="button"
          className="min-h-11 rounded-md bg-ink px-4 text-sm font-medium text-paper"
          onClick={() => {
            void navigator.clipboard.writeText(file.body).then(
              () => setCopied(true),
              () => setCopied(false),
            );
          }}
        >
          {copied ? "Скопировано" : "Скопировать файл"}
        </button>
      </div>
      <p className="mt-2 max-w-2xl text-sm text-ink-soft">
        Это не репозиторий Anna и не GitHub. Файлы кассы открыты здесь, как они есть.
      </p>
      <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
        {FILES.map((item) => (
          <button
            key={item.name}
            type="button"
            onClick={() => {
              setName(item.name);
              setCopied(false);
            }}
            className={cn(
              "min-h-11 shrink-0 rounded-md px-3 font-mono text-xs",
              item.name === file.name ? "bg-ink text-paper" : "border border-line bg-card text-ink",
            )}
          >
            {item.name.replace(/^src\//, "")}
          </button>
        ))}
      </div>
      <pre className="mt-3 max-h-[70vh] overflow-auto border border-line bg-card p-3 font-mono text-xs leading-relaxed text-ink">
        {file.body}
      </pre>
    </Shell>
  );
}

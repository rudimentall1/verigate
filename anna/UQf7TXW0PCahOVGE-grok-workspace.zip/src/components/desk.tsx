import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { canonicalize, sha256Hex, signText, verifyText, bytesToHex } from "@/lib/crypto";
import { EXAMPLES } from "@/lib/examples";
import { USDC, transferCalldata } from "@/lib/erc20";
import { extractLocal, mergeExtract, type ModelRead } from "@/lib/extract";
import { interpretPayment } from "@/lib/interpret";
import { historyFor, issueCanonical, spentUnits, submitCanonical, type LedgerRecord, type Mode } from "@/lib/ledger";
import { formatUnits } from "@/lib/money";
import { evaluate, policyCanonical, type Decision, type Intent, type RuleHit } from "@/lib/policy";
import { useDesk } from "@/lib/store";
import { cn } from "@/lib/cn";
import { Shell, useNow } from "@/components/shell";

type ResultView = {
  intent: Intent;
  rawHash: string;
  mode: Mode;
  decision: Decision;
  rules: RuleHit[];
  advisory: RuleHit[];
  canonical: string;
  signature: string;
  verified: boolean;
  policyDigest: string;
  ignoredModelBlock: boolean;
  modelRequested: string | null;
  rejected: string[];
  aiError: string | null;
  recordId: string | null;
  payeeSeen: boolean;
  spent: string;
};

type Phase =
  | { name: "ready" }
  | { name: "loading" }
  | { name: "clarify"; questions: string[]; rejected: string[] }
  | { name: "result"; view: ResultView };

const STAMP: Record<Decision, string> = {
  ALLOW: "border-allow bg-allow-bg text-allow",
  WARN: "border-warn bg-warn-bg text-warn",
  BLOCK: "border-block bg-block-bg text-block",
};

const CAPTION: Record<Decision, string> = {
  ALLOW: "Политика пропускает. Это не проверка «адрес безопасен» и не факт перевода.",
  WARN: "Нужен отдельный просмотр этих правил. Модель снять WARN не может.",
  BLOCK: "Запрет окончательный. Подтверждение человека его не отменяет.",
};

function short(value: string): string {
  return value.length < 16 ? value : `${value.slice(0, 8)}…${value.slice(-4)}`;
}

type Eip1193 = {
  request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
};

function walletProvider(): Eip1193 | null {
  if (typeof window === "undefined") return null;
  const eth = (window as Window & { ethereum?: Eip1193 }).ethereum;
  return eth && typeof eth.request === "function" ? eth : null;
}

export function Desk() {
  const policy = useDesk((state) => state.policy);
  const records = useDesk((state) => state.records);
  const issuer = useDesk((state) => state.issuer);
  const [text, setText] = useState("");
  const [phase, setPhase] = useState<Phase>({ name: "ready" });
  const [dialog, setDialog] = useState<null | "issue" | "submit" | "burn">(null);
  const [ack, setAck] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const recordId = phase.name === "result" ? phase.view.recordId : null;
  const record = useDesk((state) => (recordId ? (state.records.find((item) => item.id === recordId) ?? null) : null));
  const now = useNow(Boolean(record?.exp && !record.consumedAt && !record.releasedAt));
  const reserved = formatUnits(spentUnits(records, "USDC", now ?? 0));

  async function onCheck() {
    const raw = text.trim();
    if (!raw) return;
    setNotice(null);
    setDialog(null);
    setPhase({ name: "loading" });
    const local = extractLocal(raw);
    let model: ModelRead | null = null;
    let aiError: string | null = null;
    try {
      const result = await interpretPayment({ data: { text: raw } });
      if (result.ok) {
        model = {
          network: result.network,
          asset: result.asset,
          amount: result.amount,
          payee: result.payee,
          riskFlags: result.riskFlags,
          requestedDecision: result.requestedDecision,
        };
      } else aiError = result.error;
    } catch {
      aiError = "Хостовая модель не ответила. Ниже только политика, без полномочия на исполнение.";
    }

    const merged = mergeExtract(raw, local, model);
    if (!merged.complete || !merged.intent) {
      setPhase({ name: "clarify", questions: merged.questions, rejected: merged.rejected });
      return;
    }

    const state = useDesk.getState();
    const key = state.issuer;
    if (!key) {
      setPhase({ name: "ready" });
      setNotice("Ключ установки ещё создаётся. Нажмите проверку ещё раз.");
      return;
    }

    const moment = Date.now();
    const history = historyFor(state.records, state.attempts, merged.intent.asset, merged.intent.payee, moment);
    const evaluated = evaluate(merged.intent, state.policy, history, merged.advisory);
    const rawHash = await sha256Hex(raw);
    const policyDigest = await sha256Hex(policyCanonical(state.policy));
    const body = {
      kind: "decision",
      v: 1,
      rawHash,
      network: merged.intent.network.toLowerCase(),
      asset: merged.intent.asset.toUpperCase(),
      amount: merged.intent.amount,
      payee: merged.intent.payee,
      decision: evaluated.decision,
      rules: evaluated.rules.map((rule) => ({ code: rule.code, severity: rule.severity })),
      mode: merged.mode,
      policyDigest,
      ignoredModelBlock: merged.ignoredModelBlock,
    };
    const canonical = canonicalize(body);
    const signature = await signText(key.privatePkcs8B64, canonical);
    const verified = await verifyText(key.publicRawB64, canonical, signature);
    setAck(false);
    setPhase({
      name: "result",
      view: {
        intent: merged.intent,
        rawHash,
        mode: merged.mode,
        decision: evaluated.decision,
        rules: evaluated.rules,
        advisory: merged.advisory,
        canonical,
        signature,
        verified,
        policyDigest,
        ignoredModelBlock: merged.ignoredModelBlock,
        modelRequested: merged.modelRequested,
        rejected: merged.rejected,
        aiError,
        recordId: null,
        payeeSeen: history.payeeSeen,
        spent: formatUnits(history.spentUnits),
      },
    });
  }

  async function requestIssue(view: ResultView, armed: boolean) {
    setNotice(null);
    if (!armed) {
      setNotice("Отказ. Прямой вызов не пишет 60-секундное подтверждение интерфейса и не получает полномочие.");
      return;
    }
    const state = useDesk.getState();
    const key = state.issuer;
    if (!key || !view.verified || view.mode !== "ai" || view.decision === "BLOCK") {
      setNotice("Execution Authorization отсюда не выпускается.");
      return;
    }
    const history = historyFor(state.records, state.attempts, view.intent.asset, view.intent.payee, Date.now());
    const again = evaluate(view.intent, state.policy, history, view.advisory);
    const same =
      again.decision === view.decision &&
      again.rules.map((rule) => rule.code).join("|") === view.rules.map((rule) => rule.code).join("|");
    if (!same) {
      state.noteAttempt(Date.now());
      setNotice("Повторная проверка разошлась с экраном. Разрешение не выпущено. Проверьте платёж заново.");
      setDialog(null);
      return;
    }
    const gateCanon = issueCanonical(view.intent, again.rules.map((rule) => rule.code));
    state.openGate({ purpose: "issue", exp: Date.now() + 60_000, canonical: gateCanon });
    const gate = useDesk.getState().gate;
    if (!gate || gate.purpose !== "issue" || gate.canonical !== gateCanon || gate.exp < Date.now()) {
      setNotice("Подтверждение интерфейса не принято.");
      return;
    }

    const nonceBytes = new Uint8Array(16);
    crypto.getRandomValues(nonceBytes);
    const nonce = bytesToHex(nonceBytes);
    const exp = Date.now() + 60_000;
    const execution = {
      kind: "execution-authorization",
      v: 1,
      nonce,
      exp: new Date(exp).toISOString(),
      decision: view.canonical,
      network: view.intent.network.toLowerCase(),
      asset: view.intent.asset.toUpperCase(),
      amount: view.intent.amount,
      payee: view.intent.payee,
      rules: view.rules.map((rule) => rule.code).sort(),
    };
    const executionCanonical = canonicalize(execution);
    const executionSig = await signText(key.privatePkcs8B64, executionCanonical);
    const created: LedgerRecord = {
      id: crypto.randomUUID(),
      createdAt: Date.now(),
      exp,
      consumedAt: null,
      releasedAt: null,
      decision: view.decision,
      mode: view.mode,
      network: view.intent.network.toLowerCase(),
      asset: view.intent.asset.toUpperCase(),
      amount: view.intent.amount,
      payee: view.intent.payee,
      rules: view.rules,
      policyDigest: view.policyDigest,
      decisionCanonical: view.canonical,
      decisionSig: view.signature,
      executionCanonical,
      executionSig,
      nonce,
      walletNote: null,
      ignoredModelBlock: view.ignoredModelBlock,
    };
    state.noteAttempt(Date.now());
    state.addRecord(created);
    state.clearGate();
    setDialog(null);
    setPhase({ name: "result", view: { ...view, recordId: created.id } });
    setNotice("Разрешение выпущено на 60 секунд. В бюджет 24 часов оно уже село.");
  }

  async function requestSubmit(current: LedgerRecord, armed: boolean) {
    setNotice(null);
    if (current.consumedAt) {
      setNotice("Разрешение уже использовано. Повтор запрещён, нужна новая проверка.");
      setDialog(null);
      return;
    }
    if (current.exp !== null && current.exp < Date.now()) {
      setNotice("60 секунд прошли. Выпустите разрешение заново.");
      setDialog(null);
      return;
    }
    const expected = submitCanonical(current);
    if (!armed) {
      setNotice("Отказ. Потребление без отдельного подтверждения передачи не выполняется.");
      return;
    }
    useDesk.getState().openGate({ purpose: "submit", exp: Date.now() + 60_000, canonical: expected });
    const gate = useDesk.getState().gate;
    if (!gate || gate.purpose !== "submit" || gate.canonical !== expected || gate.exp < Date.now()) {
      setNotice("Подтверждение передачи не совпало с nonce и суммой.");
      return;
    }

    const network = current.network === "base" || current.network === "ethereum" ? current.network : null;
    const data = network ? transferCalldata(current.payee, current.amount) : null;
    const provider = walletProvider();
    if (!network || !data || !provider) {
      useDesk.getState().clearGate();
      setDialog(null);
      const why = !network
        ? "Solana в версии 0.1.29 не собирает транзакцию. Разрешение не сожжено."
        : "В этой сессии нет EIP-1193. Разрешение цело: жечь его есть зачем только когда кошелёк реально открылся.";
      setNotice(why);
      return;
    }

    const consumed = useDesk.getState().consume(current.id, "Разрешение сожжено до запроса подписи.");
    useDesk.getState().clearGate();
    setDialog(null);
    if (!consumed.ok) {
      setNotice(consumed.reason);
      return;
    }

    const chain = USDC[network];
    try {
      const accounts = (await provider.request({ method: "eth_requestAccounts" })) as string[];
      const from = accounts[0];
      if (!from) throw new Error("Кошелёк не вернул счёт");
      try {
        await provider.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: chain.chainId }],
        });
      } catch (error) {
        const code = typeof error === "object" && error && "code" in error ? Number(error.code) : 0;
        if (code === 4902 && network === "base") {
          await provider.request({
            method: "wallet_addEthereumChain",
            params: [
              {
                chainId: chain.chainId,
                chainName: "Base",
                nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
                rpcUrls: ["https://mainnet.base.org"],
                blockExplorerUrls: ["https://basescan.org"],
              },
            ],
          });
        } else throw error;
      }
      const hash = await provider.request({
        method: "eth_sendTransaction",
        params: [{ from, to: chain.token, data, value: "0x0" }],
      });
      useDesk.getState().setWalletNote(
        current.id,
        `Кошелёк вернул ${String(hash)}. Это SUBMITTED, не включение в блок и не финальность.`,
      );
      setNotice("Кошелёк принял запрос. Вердикт сети эта касса не подтверждает.");
    } catch (error) {
      const message = error instanceof Error ? error.message : "запрос оборван";
      useDesk
        .getState()
        .setWalletNote(
          current.id,
          `Подпись не получена (${message}). Разрешение уже сожжено, резерв 24 часов на месте — снимите его, если перевод не ушёл.`,
        );
      setNotice("Кошелёк отклонил или оборвал подпись. Резерв можно снять: в App 0.1.29 он остался бы висеть.");
    }
  }

  function burn(current: LedgerRecord) {
    const result = useDesk.getState().consume(current.id, "Сожжено вручную, без кошелька. Повтор не пройдёт.");
    setDialog(null);
    setNotice(result.ok ? "Разрешение использовано. Вторая передача получит отказ." : result.reason);
  }

  const view = phase.name === "result" ? phase.view : null;
  const left = view && record?.exp && now ? Math.max(0, Math.ceil((record.exp - now) / 1000)) : null;

  return (
    <Shell>
      <div className="grid gap-6 lg:grid-cols-12">
        <section className="lg:col-span-5">
          <div className="flex items-baseline justify-between gap-3">
            <h2 className="text-lg font-semibold">Запрос</h2>
            <p className="font-mono text-xs text-ink-soft tabular-nums">резерв 24ч {reserved} / {policy.dailyCap.USDC ?? "—"} USDC</p>
          </div>
          <label htmlFor="request" className="mt-3 block text-sm text-ink-soft">
            Обычными словами: сумма, актив, сеть, адрес.
          </label>
          <textarea
            id="request"
            value={text}
            maxLength={2000}
            onChange={(event) => setText(event.target.value)}
            onKeyDown={(event) => {
              if ((event.metaKey || event.ctrlKey) && event.key === "Enter") void onCheck();
            }}
            placeholder="Заплати 25 USDC в сети Base на 0x…"
            className="field mt-2 min-h-36 resize-y"
            suppressHydrationWarning
          />
          <div className="mt-3 flex flex-wrap gap-2">
            {EXAMPLES.map((example) => (
              <button
                key={example.id}
                type="button"
                onClick={() => {
                  setText(example.text);
                  setPhase({ name: "ready" });
                  setNotice(null);
                }}
                className="min-h-11 rounded-md border border-line bg-card px-3 text-left text-sm"
              >
                <span className="block font-medium">{example.label}</span>
                <span className="block text-xs text-ink-soft">{example.hint}</span>
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={() => void onCheck()}
            disabled={phase.name === "loading" || text.trim().length === 0}
            className="mt-4 inline-flex min-h-11 w-full items-center justify-center rounded-md bg-ink px-4 text-sm font-medium text-paper disabled:opacity-50 sm:w-auto"
          >
            {phase.name === "loading" ? "Проверяю" : "Проверить"}
          </button>
          <p className="mt-3 text-sm text-ink-soft">
            Превью не пишет попытку и не создаёт разрешение. Квалифицированный результат — само решение.
          </p>
        </section>

        <section className="lg:col-span-7">
          {phase.name === "ready" ? <Primer /> : null}
          {phase.name === "loading" ? <p className="text-sm text-ink-soft">Сначала текст, потом политика. Модель не голосует.</p> : null}
          {phase.name === "clarify" ? (
            <div className="border border-line bg-card p-4">
              <h2 className="text-lg font-semibold">Не хватает точного поля</h2>
              <p className="mt-1 text-sm text-ink-soft">Политика не запускалась. Модель не имеет права додумать сумму или адрес.</p>
              <ul className="mt-3 space-y-2 text-sm">
                {phase.questions.map((question) => (
                  <li key={question}>{question}</li>
                ))}
                {phase.rejected.map((question) => (
                  <li key={question}>{question}</li>
                ))}
              </ul>
            </div>
          ) : null}
          {view ? (
            <Result
              view={view}
              policyNetworks={policy.allowedNetworks.join(", ")}
              policyAssets={policy.allowedAssets.join(", ")}
              caps={policy}
              record={record}
              secondsLeft={left}
              notice={notice}
              copied={copied}
              onIssue={() => setDialog("issue")}
              onAttack={() => void requestIssue(view, false)}
              onSubmit={() => setDialog("submit")}
              onAttackSubmit={() => record && void requestSubmit(record, false)}
              onBurn={() => setDialog("burn")}
              onRelease={() => {
                if (!record) return;
                const result = useDesk.getState().release(record.id);
                setNotice(result.ok ? "Резерв снят. Запись в журнале осталась." : result.reason);
              }}
              onCopy={(value, label) => {
                void navigator.clipboard.writeText(value).then(
                  () => setCopied(label),
                  () => setCopied("не скопировано"),
                );
              }}
            />
          ) : null}
        </section>
      </div>

      {dialog && view ? (
        <div className="fixed inset-0 z-40 flex items-end justify-center bg-ink/40 p-3 sm:items-center" role="presentation">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="gate-title"
            className="w-full max-w-lg border border-line bg-paper p-4 text-ink shadow-none"
          >
            <h2 id="gate-title" className="text-lg font-semibold">
              {dialog === "issue" ? "Подтверждение платежа" : dialog === "submit" ? "Передача в кошелёк" : "Сжечь разрешение"}
            </h2>
            <p className="mt-1 text-sm text-ink-soft">
              {dialog === "issue"
                ? "Это 60-секундная запись интерфейса. Чат и прямой вызов инструмента такую запись создать не могут."
                : dialog === "submit"
                  ? "Отдельное подтверждение передачи. Разрешение сгорит до того, как кошелёк спросит подпись."
                  : "Без кошелька, чтобы увидеть отказ на повторе. Бюджет 24 часов сам не вернётся."}
            </p>
            <dl className="mt-3 space-y-1 font-mono text-xs">
              <Row k="сеть" v={view.intent.network} />
              <Row k="актив" v={view.intent.asset.toUpperCase()} />
              <Row k="сумма" v={view.intent.amount} />
              <Row k="кому" v={view.intent.payee} />
            </dl>
            {dialog === "issue" && view.decision === "WARN" ? (
              <div className="mt-3">
                <ul className="space-y-2 text-sm">
                  {view.rules.map((rule) => (
                    <li key={rule.code}>
                      <span className="font-mono text-xs">{rule.code}</span>
                      <span className="mt-0.5 block text-ink-soft">{rule.detail}</span>
                    </li>
                  ))}
                </ul>
                <label className="mt-3 flex min-h-11 items-start gap-2 text-sm">
                  <input type="checkbox" checked={ack} onChange={(event) => setAck(event.target.checked)} className="mt-1" />
                  Подтверждаю именно эти правила, не «вообще осторожно».
                </label>
              </div>
            ) : null}
            <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:justify-end">
              <button type="button" className="min-h-11 rounded-md border border-line px-4 text-sm" onClick={() => setDialog(null)}>
                Отмена
              </button>
              <button
                type="button"
                disabled={dialog === "issue" && view.decision === "WARN" && !ack}
                onClick={() => {
                  if (dialog === "issue") void requestIssue(view, true);
                  else if (dialog === "submit" && record) void requestSubmit(record, true);
                  else if (dialog === "burn" && record) burn(record);
                }}
                className="min-h-11 rounded-md bg-ink px-4 text-sm font-medium text-paper disabled:opacity-50"
              >
                {dialog === "issue" ? "Выпустить разрешение" : dialog === "submit" ? "Передать" : "Сжечь"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </Shell>
  );
}

function Primer() {
  return (
    <div className="border border-line bg-card p-4">
      <h2 className="text-lg font-semibold">Три разных замка</h2>
      <ol className="mt-3 space-y-3 text-sm">
        <li>
          <span className="font-medium">1. Модель.</span> Вытаскивает поля и может поднять риск. Сумму, которой нет в тексте, она не протащит.
        </li>
        <li>
          <span className="font-medium">2. Политика.</span> ALLOW, WARN или BLOCK. Цифры — как в Anna App 0.1.29, пока вы их не смените.
        </li>
        <li>
          <span className="font-medium">3. Кошелёк.</span> Видит перевод только после одноразового разрешения. Ключи остаются у него.
        </li>
      </ol>
      <p className="mt-4 text-sm text-ink-soft">Выберите пример слева. 25 — пропуск, 80 — новый адрес, 400 — давление на модель, 900 — жёсткий потолок.</p>
      <p className="mt-3 text-sm">
        <Link to="/audit" className="text-copper">
          Сверка с цифрами 0.1.29
        </Link>{" "}
        гоняет эти правила здесь и в журнал не пишет.
      </p>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex gap-3">
      <dt className="w-16 shrink-0 text-ink-soft">{k}</dt>
      <dd className="break-all">{v}</dd>
    </div>
  );
}

function Result({
  view,
  caps,
  policyNetworks,
  policyAssets,
  record,
  secondsLeft,
  notice,
  copied,
  onIssue,
  onAttack,
  onSubmit,
  onAttackSubmit,
  onBurn,
  onRelease,
  onCopy,
}: {
  view: ResultView;
  caps: { perTxCap: Record<string, string>; newPayeeCap: Record<string, string>; confirmationRequiredOver: Record<string, string>; dailyCap: Record<string, string> };
  policyNetworks: string;
  policyAssets: string;
  record: LedgerRecord | null;
  secondsLeft: number | null;
  notice: string | null;
  copied: string | null;
  onIssue: () => void;
  onAttack: () => void;
  onSubmit: () => void;
  onAttackSubmit: () => void;
  onBurn: () => void;
  onRelease: () => void;
  onCopy: (value: string, label: string) => void;
}) {
  const asset = view.intent.asset.toUpperCase();
  const calldata =
    view.intent.network === "base" || view.intent.network === "ethereum"
      ? transferCalldata(view.intent.payee, view.intent.amount)
      : null;
  const rows = [
    ["Транзакция", caps.perTxCap[asset] ?? "—", view.intent.amount],
    ["Первый адрес", caps.newPayeeCap[asset] ?? "—", view.payeeSeen ? "уже был" : "новый"],
    ["Просмотр свыше", caps.confirmationRequiredOver[asset] ?? "—", view.intent.amount],
    ["Бюджет 24ч", caps.dailyCap[asset] ?? "—", `${view.spent} уже в резерве`],
    ["Сеть", policyNetworks, view.intent.network],
    ["Актив", policyAssets, asset],
  ];
  const canIssue = view.mode === "ai" && view.decision !== "BLOCK" && view.verified && !record;

  return (
    <div className="space-y-4">
      <div className={cn("border p-4", STAMP[view.decision])}>
        <p className="font-mono text-3xl tracking-widest">{view.decision}</p>
        <p className="mt-1 text-sm">{CAPTION[view.decision]}</p>
      </div>

      <div className="flex flex-wrap gap-2 text-xs">
        <span className="border border-line bg-card px-2 py-1">
          {view.mode === "ai" ? "разбор модели был" : "policy-only, без полномочия"}
        </span>
        <span className="border border-line bg-card px-2 py-1">{view.verified ? "подпись чека сходится" : "подпись чека не сошлась"}</span>
        {view.ignoredModelBlock ? <span className="border border-line bg-card px-2 py-1">BLOCK модели выброшен</span> : null}
      </div>

      {view.aiError ? <p className="text-sm text-ink-soft">{view.aiError}</p> : null}
      {view.modelRequested && view.modelRequested.toUpperCase() !== "NULL" ? (
        <p className="text-sm">Модель просила {view.modelRequested}. На вердикт это не влияет.</p>
      ) : null}
      {view.rejected.length > 0 ? (
        <ul className="text-sm text-ink-soft">
          {view.rejected.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      ) : null}

      <table className="w-full border-collapse text-sm">
        <caption className="sr-only">Запрос против лимитов</caption>
        <thead>
          <tr className="border-b border-line text-left text-xs text-ink-soft">
            <th className="py-2 font-medium">Поле</th>
            <th className="py-2 font-medium">Лимит</th>
            <th className="py-2 font-medium">Запрос</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(([label, limit, asked]) => (
            <tr key={label} className="border-b border-line">
              <td className="py-2 pr-2">{label}</td>
              <td className="py-2 pr-2 font-mono text-xs">{limit}</td>
              <td className="py-2 font-mono text-xs">{asked}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {view.rules.length > 0 ? (
        <ul className="space-y-2">
          {view.rules.map((rule) => (
            <li key={rule.code} className="border border-line bg-card px-3 py-2 text-sm">
              <span className="font-mono text-xs">{rule.severity} · {rule.code}</span>
              <span className="mt-1 block">{rule.detail}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-ink-soft">Ни одно правило не сработало.</p>
      )}

      {canIssue ? (
        <button type="button" onClick={onIssue} className="inline-flex min-h-11 w-full items-center justify-center rounded-md bg-copper px-4 text-sm font-medium text-paper sm:w-auto">
          {view.decision === "WARN" ? "Разобрать предупреждения" : "Подтвердить и выпустить разрешение"}
        </button>
      ) : null}
      {view.mode !== "ai" && view.decision !== "BLOCK" ? (
        <p className="text-sm">Без контекстного разбора модели Execution Authorization не выпускается. Чек решения — да.</p>
      ) : null}
      {!record ? (
        <button type="button" onClick={onAttack} className="inline-flex min-h-11 items-center text-sm text-copper underline-offset-2">
          Вызвать инструмент в обход подтверждения
        </button>
      ) : null}

      {record?.executionSig ? (
        <div className="border border-line bg-card p-4">
          <h3 className="font-semibold">Execution Authorization</h3>
          <p className="mt-1 font-mono text-xs text-ink-soft">
            nonce {record.nonce} · {record.consumedAt ? "использовано" : record.releasedAt ? "резерв снят" : secondsLeft === null ? "живёт" : `${secondsLeft} с`}
          </p>
          {calldata ? (
            <p className="mt-3 break-all font-mono text-xs">{calldata}</p>
          ) : (
            <p className="mt-3 text-sm">Calldata нет. Solana в этом релизе не уходит в кошелёк.</p>
          )}
          {record.walletNote ? <p className="mt-3 text-sm">{record.walletNote}</p> : null}
          <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:flex-wrap">
            <button type="button" onClick={onSubmit} className="min-h-11 rounded-md bg-ink px-4 text-sm font-medium text-paper">
              Подтвердить передачу
            </button>
            <button type="button" onClick={onBurn} className="min-h-11 rounded-md border border-line px-4 text-sm">
              Сжечь без кошелька
            </button>
            <button type="button" onClick={onRelease} className="min-h-11 rounded-md border border-line px-4 text-sm">
              Снять резерв
            </button>
          </div>
          <button type="button" onClick={onAttackSubmit} className="mt-3 inline-flex min-h-11 items-center text-sm text-copper">
            Потребить без подтверждения передачи
          </button>
          <p className="mt-2 text-xs text-ink-soft">Снятие резерва есть в этой кассе и ещё нет в App 0.1.29.</p>
        </div>
      ) : null}

      {notice ? <p className="text-sm">{notice}</p> : null}

      <details className="border border-line bg-card p-3 text-sm">
        <summary className="min-h-11 cursor-pointer font-medium">Чек и ключ</summary>
        <p className="mt-2 text-ink-soft">Сверьте отпечаток с тем, что в шапке. Чужой канал доставки ключа эта страница не заменяет.</p>
        <pre className="mt-3 overflow-x-auto whitespace-pre-wrap break-all font-mono text-xs">{view.canonical}</pre>
        <p className="mt-2 break-all font-mono text-xs">{view.signature}</p>
        <button type="button" className="mt-3 min-h-11 text-sm text-copper" onClick={() => onCopy(`${view.canonical}\n${view.signature}`, "чек")}>
          {copied === "чек" ? "Скопировано" : "Скопировать чек"}
        </button>
      </details>
    </div>
  );
}

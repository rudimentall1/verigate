import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { createIssuer } from "@/lib/crypto";
import { cn } from "@/lib/cn";
import { useDesk } from "@/lib/store";

const NAV = [
  { to: "/", label: "Проверка" },
  { to: "/ledger", label: "Журнал" },
  { to: "/policy", label: "Политика" },
  { to: "/audit", label: "Аудит" },
  { to: "/code", label: "Код" },
] as const;

export function Shell({ children }: { children: React.ReactNode }) {
  const fingerprint = useDesk((state) => state.issuer?.fingerprint ?? null);
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  useEffect(() => {
    let dead = false;
    const boot = async () => {
      if (!useDesk.persist.hasHydrated()) await useDesk.persist.rehydrate();
      if (!useDesk.getState().issuer) useDesk.getState().setIssuer(await createIssuer());
      if (dead) return;
    };
    void boot();
    return () => {
      dead = true;
    };
  }, []);

  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-mono text-xs tracking-widest text-copper">VERIGATE</p>
            <h1 className="text-2xl font-semibold leading-tight">Касса полномочий</h1>
            <p className="mt-1 max-w-xl text-sm text-ink-soft">
              Модель советует. Потратить она не может. Решение подписывает установка, перевод — только кошелёк.
            </p>
          </div>
          <p className="font-mono text-xs text-ink-soft sm:text-right">
            ключ установки
            <span className="mt-1 block text-sm text-ink">{fingerprint ?? "создаётся на этом устройстве"}</span>
          </p>
        </div>
        <nav className="mx-auto flex max-w-6xl gap-2 overflow-x-auto px-4 pb-3">
          {NAV.map((item) => {
            const path = pathname.length > 1 ? pathname.replace(/\/$/, "") : pathname;
            const active = item.to === "/" ? path === "/" : path === item.to || path.endsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "inline-flex min-h-11 shrink-0 items-center rounded-md px-3 text-sm font-medium",
                  active ? "bg-ink text-paper" : "text-ink",
                )}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>
      <footer className="mx-auto max-w-6xl px-4 pb-10 text-xs text-ink-soft">
        Anna App 851 · immutable Draft 0.1.29 · Executa 0.1.16. Не опубликован и не является кошельком. Чек
        доказывает целостность решения этой установки, не факт перевода в сети.
      </footer>
    </div>
  );
}

export function useNow(active: boolean): number | null {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    if (!active) return;
    const tick = () => setNow(Date.now());
    tick();
    const timer = window.setInterval(tick, 1000);
    return () => window.clearInterval(timer);
  }, [active]);
  return now;
}
